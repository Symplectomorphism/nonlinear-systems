(* ::Package:: *)

(************************************************************************
                                  ControlL

           
Copyright \[Copyright] 2017 H. G. Kwatny.
All Rights Reserved          
           
***************************************************************************)
spell1 = (Head[General::spell1] === $Off);
spell = (Head[General::spell] === $Off);
Off[General::spell1];
Off[General::spell];

If[$VersionNumber===2.,BeginPackage["ProPac`ControlL`",{"ProPac`GeoTools`","LinearAlgebra`MatrixManipulation`",
    "Algebra`ReIm`","Graphics`Graphics`","Graphics`Legend`","Calculus`Limit`","Calculus`LaplaceTransform`",
    "Calculus`Common`TransformCommon`"}]];
If[$VersionNumber===3.,BeginPackage["ProPac`ControlL`",{"ProPac`GeoTools`","LinearAlgebra`MatrixManipulation`",
    "Algebra`ReIm`","Graphics`Graphics`","Graphics`Legend`","Calculus`Limit`","Calculus`LaplaceTransform`",
    "Calculus`Common`TransformCommon`"}]];
If[($VersionNumber>=4.)&&($VersionNumber<5.),BeginPackage["ProPac`ControlL`",{"ProPac`GeoTools`","LinearAlgebra`MatrixManipulation`",
    "Algebra`ReIm`","Graphics`Graphics`","Graphics`Legend`",
    "Calculus`Limit`"}]];
If[$VersionNumber===5.,BeginPackage["ProPac`ControlL`",{"ProPac`GeoTools`","LinearAlgebra`MatrixManipulation`",
    "Algebra`ReIm`","Graphics`Graphics`","Graphics`Legend`"}]];
If[$VersionNumber===6.,BeginPackage["ProPac`ControlL`",{"ProPac`GeoTools`","LinearAlgebra`MatrixManipulation`",
    "PlotLegends`"}]];
If[$VersionNumber>=7.,BeginPackage["ProPac`ControlL`",{"ProPac`GeoTools`"}]];
(****************************************************************)

(* Package Help *)

(****************************************************************)

LinearControl::usage=
"Functions in the package for linear control are:\n
\n
jacobian, TaylorLinearize,\n 
RandomMatrix, RangeSpace, MatrixTrace,n
BlockCompanionMatrix,\n
\n
StateSpaceToTransferFunction,\n
LeastCommonDenominator, Poles, Zeros,\n
AssociatedHankelMatrix,LaurentSeries,\n
McMillanDegree,ControllableRealization,\n
ObservableRealization, MinimalRealization,\n
\n
controllabilityMatrix, observabilityMatrix,\n
ControllablePair, ObservablePair,\n
KalmanDecomposition,RelativeDegree,\n
\n
AlgebraicRiccatiEquation,LQR,LQE,\n
DecouplingControl,PolePlace,\n
LyapunovEquation,\n
\n
RootLocus,Nyquist,ColorNyquist,Bode,\n
PoleZeroPlot";

(* usage messages for the exported functions and the context itself *)
   
LyapunovEquation::usage = 
"LyapunovEquation[A,Q] Returns the solution P of the Matrix\n
Lyapunov equation\n
      PA + A^TP = -Q\n
Ordinarily, Q is a symmetric, positive semidefiite matrix.
"

AlgebraicRiccatiEquation::usage =
"AlgebraicRiccatiEquation[A,Q,U] computes the positive definite solution\n
P of the algebraic Riccati equation\n
         PA + A'P - PUP + Q = 0\n
where Q and U are nxn positive semidefinite symmetric matrices and\n 
A is detectable in Q and stabilizable with respect to U."

LQR::usage = 
"{K,P,Eigs} = LQR[A,B,Q,R] calculates the optimal feedback gain\n 
matrix K such that the feedback law  u = Kx  minimizes the \n
cost function:\n
\n
     J = int_0^infty x^T Qx + u^T Ru dt\n
\n
subject to the state equation\n
     .\n
     x = Ax + Bu\n
\n
Also returned is P, the steady-state solution to the associated\n 
algebraic Riccati equation:\n
\n
       0 = PA + A^T P - PBR^{-1} B^T P + Q\n
";

LQE::usage = 
"Executes linear quadratic estimator design for the continuous\n
time system:\n
     .\n
     x = Ax + Bu + Gw, (State equation)\n
\n
     z = Cx + Du + v,  (Measurements)\n
\n
with process noise and measurement noise covariances:\n
\n
      Ew = Ev = 0, Eww^T = Q, Evv^T = R\n
\n
The function LQE[A,G,C,Q,R] determines the gain matrix L\n
such that the stationary Kalman filter:\n
      .\n
      x = Ax + Bu + L(Cx + Du - z)\n
\n
produces an LQG optimal estimate of x.\n
{L,P,Eigs} = LQE[A,G,C,Q,R] returns the gain matrix L and the Riccati\n
equation solution P which is the estimate error covariance. The\n 
estimator parameters are obtained using LQR and duality.";

DecouplingControl::usage = 
"DecouplingControl[A,B,C] computes the feedback gain K and coordinate\n
change G which decouple the closed loop feedback system \n
         xdot = A x + B u, \n
that is, u=Kx+Gv, with K=-E^-1 F, G=E^-1\n
when the\n
Falb--Wolovich decoupling conditions are satisfied.";

RelativeDegree::usage = 
"RelativeDegree[A,B,C] computes the vector of relative degrees of\n
the transfer function G[s]=C (Is-A)^-1 B.\n 
RelativeDegree[G,s] assumes the first argument is a transfer function.";

Until::usage=
"From R. Maeder, Programming in Mathematica: Until[body,test] checks
the test after each iteration of body.";

Kernel::usage = 
"Kernel[A] finds the null space of the matrix A.";

RangeSpace::usage = 
"RangeSpace[A] finds the range space of the matrix A.";

MatrixTrace::usage =
"MatrixTrace[A] computes the trace of the square matrix A.";

(*
MatrixRank::usage = 
"MatrixRank[A], with A a numerical (real values) nxm matrix, returns
the rank of the matrix. It uses the singular value decomposition
of the matrix A.";
*)

Poles::usage = 
"Poles[G,s] finds the roots of the LeastCommonDenominator of all minors\n
of all orders of a proper rational (matrix) transfer function G[s]. It\n
returns a list consisting of the distinct values of the poles and their\n 
multiplicities. The poles correspond to the eigenvalues of a minimal\n
realization of G[s].\n
Examples:\n 
\n
G[s_]:={{s-1,s},{-6,s-2}}/(1.25*(s+1)*(s+2))\n
Poles[G,s] returns the list {{-2,1},{-1,1}}\n
\n
G[s_]:={{(s-1)*(s+2),0,(s-1)^2},\n
   {-(s+1)*(s+2),(s-1)*(s+1),(s-1)*(s+1)}}/((s+1)*(s+2)*(s-1))\n
Poles[G,s] returns the list {{-2,2},{-1,1},{1,1}}\n
";

Zeros::usage =
"Zeros[G,s] finds the transmission zeros of a proper rational (matrix)\n
transfer funtion G[s]. They correspond to the zeros of a mimal realization\n
G[s]. It returns a list of pairs of the distinct values of the zeros and\n
their multiplicities.\n
Examples:\n
\n
G[s_]:={{s-1,s},{-6,s-2}}/(1.25*(s+1)*(s+2))\n
Zeros[G,s] returns {}\n
\n
G[s_]:={{(s-1)*(s+2),0,(s-1)^2},\n
   {-(s+1)*(s+2),(s-1)*(s+1),(s-1)*(s+1)}}/((s+1)*(s+2)*(s-1))\n
Zeros[G,s] returns {{1,1}}\n
\n
G[s_]:={{s-1,4},{4.5,2*(s-1)}}/(s+2)\n
Zeros[G,s] returns {{4,1}}
"

ControllableRealization::usage = 
"ControllableRealization[G,s] constructs the controllable realization
of a transfer function G[s]. It handles both scalar and matrix cases.";

AssociatedHankelMatrix::usage =
"AssociatedHankelMatrix[G,s] computes the Hankel matrix associated with the
Laurent expansion of the transfer function G[s].";

LaurentSeries::usage = 
"LaurentSeries[G,s,n] computes the first n terms of the 
Laurent series expansion of G[s] about s=Infinity. It includes a
formal remainder estimate. Use Normal[...] to keep only the terms.";

McMillanDegree::usage = 
"McMillanDegree[G,s] computes the degree of the minimal
realization of a transfer function (matrix or scalar valued).";

ObservableRealization::usage = 
"ObservableRealization[G,s] constructs the observable realization
of a transfer function G[s]. It handles both scalar and matrix cases.";

MinimalRealization::usage=
"MinimalRealization[G,s] returns a minimal realization for a transfer\n
matrix G[s]. Example:\n
\n   
G[s_]:={{1/((s+2)^3 (s+5)),1/(s+5)},{1/(s+2),0}}\n
\n
{AA,BB,CC,DD}=MinimalRealization[G,s]\n
\n
returns\n
\n
AA {{-2,1,0,0},{0,-2,1,0},{0,0,-2,0},{0,0,0,-5}}
BB {{0,0},{0,0},{1,0},{1,-27}}
CC {{1/3, -1/9, 1/27, -730/27}, {0, 0, 1, 0}}
DD {{0,0},{0,0}}
\n
MinimalRealization can also be called with the synatx:\n
\n
MinimalRealization[A,B,C,D]\n
\n
if the system is defined in state space form. MinimalRealization\n
always returns a system in Jordan Canonical form. An analternative\n
irreducible realization for systems in state variable form can be\n
obtained with KalmanDecomposition.
"

KalmanDecomposition::usage=
"KalmanDecomposition[AA,BB,CC,DD,opts] returns a canonical for exhibiting\n
the four subsystems: controllable & observable, controllable & not \n
observable, not controllable & observable, not controllable & not observable.\n
An option (IrreducibleRealization->True) returns only the minimal\n
(or irreducible) system, i.e., the controllable & observable part. Example:
\n
AA={{1,1,0},{0,1,0},{0,1,1}};
BB={{0,1},{1,0},{0,1}};
CC={{1,1,1}};
DD={{0,0}};
\n
{Anew,Bnew,Cnew,Dnew}=KalmanDecomposition[AA,BB,CC,DD];\n
\n
returns
Anew {{1,1,0},{0,1,0},{0,0,1}}
Bnew {{0,1},{1,0},{0,0}}
Cnew {{2,1,0}}
Dnew {{0,0}}
\n
Using the option\n
{Anew,Bnew,Cnew,Dnew}=\n
KalmanDecomposition[AA,BB,CC,DD,IrreducibleRealization->True];\n
\n
Anew {{1,1},{0,1}}
Bnew {{0,1},{1,0}}
Cnew {{2,1}}
Dnew {{0,0}}
"

BlockCompanionMatrix::usage = 
"BlockCompanionMatrix[poly_coeff, block_size] 
constructs a block companion matrix with 
the blocks of size block_size, an integer. 
The poly_coeff is the list of coefficients
of a monic polynomial with the coefficient 1 
of the highest power omitted.

Example: BlockCompanionMatrix[{p0,p1,p2},2]
associated with the polynomial 
p[s] = p0 + p1 s + p2 s^2 + s^3
and block size 2.";

StateSpaceToTransferFunction::usage=
"StateSpaceToTransferFunction[A,B,C,D,s] computes the
transfer function of a linear system defined by the state
equation 
                xdot=A x + B u, y=C x + D u, 
It returns the function 
                C(Is-A)^{-1}B + D
All entries must be matrices. An error is given if the
dimensions are not correct.";

LeastCommonDenominator::usage = 
"LeastCommonDenominator[G,s] finds the least 
common denominator of the elements of the 
matrix transfer function G[s].
G[s] must be a proper rational function of s; 
and the element denominators must be monic 
polynomials in s. Common factors between 
numerator and denominator are cancelled.";

PolePlace::usage = 
"PolePlace[A,b,poles], with b a vector, uses Ackermann's formula 
to place the poles of the closed loop
system  A-bk^T at the locations {pole_1, ... , pole_n}
defined in the list poles. Complex poles in the
list must appear in consecutive complex conjugate pairs.

PolePlace[A,B,poles], with B a matrix, finds the ``most
controllable'' port of the pair (A,B), defined as the port yielding
the lowest condition number for the Controllability matrix, and uses
Ackermann's formula to place the poles of A-BK through this port. 
It returns a matrix gain. 

PolePlace[A,B,port,poles], with B a matrix and port an integer
between 1 and the number of columns of B, uses Ackermann's formula to
place the poles through the designated port.";

ObservablePair::usage =
"ObservablePair[A,C] tests the pair of matrices (A,C) to
determine if they are observable";

ControllablePair::usage =
"ControllablePair[A,B] tests the pair of matrices (A,B) to
determine if they are Controllable";

observabilityMatrix::usage = 
"observabilityMatrix[A,C] computes the observability matrix
defined by the matrices A,C.";

controllabilityMatrix::usage = 
"controllabilityMatrix[A,B] computes the Controllability matrix
defined by the matrices A,B.";

jacobian::usage= "jacobian[f_, x_] returns the jacobian matrix
of f  
with respect to x. Both f and x must be lists.";

TaylorLinearize::usage = 
"TaylorLinearize[f,g,x,x0,u,u0] linearizes the nonlinear system\n 
\n
      .\n
      x = f(x,u)\n
      y = g(x,u)\n
\n
around the vectors x = x0 and u = u0.\n
The arguments may be scalars as well as vectors\n
\n
The result will have the form {A,B,C,D}.\n
\n
TaylorLinearize[F,f,g,x,x0,u,u0] linearizes the nonlinear system\n 
\n
       .\n
   F(x)x = f(x,u)\n
       y = g(x,u)\n
\n
with E nonsingular. The result is of the form\n
{E,A,B,C,D}.
";

RandomMatrix::usage=
"RandomMatrix[n,m] returns an n times m 
matrix of random entries between -1.0 and 1.0.
RandomMatrix[n] returns an n times n matrix 
of random entries between -1.0 and 1.0.";




 
Unprotect[ControllableDecomposition,ObservableDecomposition];

Begin["`Private`"];   (* begin the private context *)

Clear[squareMatrixQ];
squareMatrixQ = MatrixQ@# && Equal @@ Dimensions@# &;
 
Clear[LyapunovEquation];
LyapunovEquation[A_?MatrixQ,Q_?MatrixQ]:=Module[{RR,n,m},
		{n,m}=Dimensions[A];
		If[(Dimensions[Q]=!={m,n})||(m=!=n),
      Print["Arguments have incorrect dimensions."];Return[{}]];
		RR=Table[ rr[i1,j1], {i1,1,n},{j1,1,n}];
		RR=RR/.Flatten[ Solve[ RR.A+Transpose[A].RR==-Q,Flatten[RR]]]
		]
SetAttribute[LyapunovEquation,ReadProtected];
SetAttribute[LyapunovEquation,Protected];
SetAttribute[LyapunovEquation,Locked];

Clear[AlgebraicRiccatiEq];
AlgebraicRiccatiEq[A_,Q_,U_]:=Module[{H1,H2,H,t,n,Theta11,Theta21,
   Theta,Pt,P,Rules1},
    H1=Join[A,-Q];
    H2=Join[-U,-Transpose[A]];
    H=Transpose[Join[Transpose[H1],Transpose[H2]]];
    Theta=HamiltonianMatExp[Rationalize[H],t];
    n=Length[A];
    Rules1={(Exp[a_?NumberQ*t]/;a>0)->0,Exp[t]->0};
    Theta11=Theta[[ Range[1,n],Range[1,n] ]]/.Rules1;
    Theta21=Theta[[ Range[n+1,2*n],Range[1,n] ]]/.Rules1;
    Pt=Simplify[BInvA[Theta11,Theta21]];
    P=Pt;
    Limit[P,t->-Infinity]
    ];
SetAttribute[AlgebraicRiccatiEq,ReadProtected];
SetAttribute[AlgebraicRiccatiEq,Locked];

Clear[AlgebraicRiccatiEquation];
AlgebraicRiccatiEquation[A_,Q_,U_]:=Module[{H1,H2,H,t,n,Theta11,Theta21,
   P,Eigs,V,Seigs,IndexList},
    n=Length[A];
    H1=Join[A,-Q];
    H2=Join[-U,-Transpose[A]];
    H=Transpose[Join[Transpose[H1],Transpose[H2]]];
    {Eigs,V}=Eigensystem[H];
    {Seigs,IndexList}=EigSort[Eigs];
    Theta11=Transpose[V[[ IndexList[[Range[1,n]]],Range[1,n] ]]];
    Theta21=Transpose[V[[ IndexList[[Range[1,n]]],Range[n+1,2*n] ]]];
    If[MatrixRank[Theta11]==Length[Theta11],
    P=Re[ComplexExpand[Simplify[BInvA[Theta11,Theta21]]]],
    Print["Hamiltonian has nonsimple divisors."];
    Print["This could take a while."];
    P=AlgebraicRiccatiEq[A,Q,U]];
    {P,Seigs[[ Range[1,n] ]]}
        ];
SetAttribute[AlgebraicRiccatiEquation,ReadProtected];
SetAttribute[AlgebraicRiccatiEquation,Locked];

Clear[LQR];
LQR[A_?squareMatrixQ,B_?MatrixQ,Q_?MatrixQ,R_?MatrixQ]:=
    Module[{RIBT,U,P,Eigs,K},
        RIBT=InvAB[R,Transpose[B]];
        U=B.RIBT;
        {P,Eigs}=AlgebraicRiccatiEquation[A,Q,U];
        K=-RIBT.P;
        {K,P,Eigs}
        ]
LQR[A_?squareMatrixQ,B_?VectorQ,Q_?MatrixQ,R_?MatrixQ]:=
   LQR[A,Transpose[{B}],Q,R];
LQR[A_?squareMatrixQ,B_?VectorQ,Q_?MatrixQ,R_Real]:=
   LQR[A,Transpose[{B}],Q,{{R}}];
LQR[A_Real,B_Real,Q_Real,R_Real]:=
   LQR[{{A}},{{B}},{{Q}},{{R}}];
SetAttribute[LQR,ReadProtected];
SetAttribute[LQR,Locked];


Clear[LQE];
LQE[A_?squareMatrixQ,G_?MatrixQ,C_?MatrixQ,Q_?MatrixQ,R_?MatrixQ]:= 
  Module[{K,P,Eigs}, 
        {K,P,Eigs} = LQR[Transpose[A],Transpose[C],G.Q.Transpose[G],R];
        {Transpose[K],Transpose[P],Eigs}
        ]
LQE[A_?squareMatrixQ,G_?MatrixQ,C_?VectorQ,Q_?MatrixQ,R_?MatrixQ]:=
  LQE[A,G,{C},Q,R];
LQE[A_?squareMatrixQ,G_?MatrixQ,C_?VectorQ,Q_?MatrixQ,R_Real]:=
  LQE[A,G,{C},Q,{{R}}];
LQE[A_?squareMatrixQ,G_?VectorQ,C_?MatrixQ,Q_?MatrixQ,R_?MatrixQ]:=
  LQE[A,Transpose[{G}],C,Q,R];
LQE[A_?squareMatrixQ,G_?VectorQ,C_?MatrixQ,Q_Real,R_?MatrixQ]:=
  LQE[A,Transpose[{G}],C,{{Q}},R];
LQE[A_?squareMatrixQ,G_?VectorQ,C_?VectorQ,Q_Real,R_Real]:=
  LQE[A,Transpose[{G}],{C},{{Q}},{{R}}];
LQE[A_Real,G_Real,C_Real,Q_Real,R_Real]:=
  LQE[{{A}},{{G}},{{C}},{{Q}},{{R}}];
SetAttribute[LQE,ReadProtected];
SetAttribute[LQE,Locked];
    

Clear[McMillanDegree];
McMillanDegree[G_,s_]:=  
    Module[{lcd,len,real,A,B},
        lcd=LeastCommonDenominator[G,s]; (* LCD of elements *)
        len=Exponent[lcd,s];             (* Highest power *)
real=ObservableRealization[G,s];    (* Compute Observable Realization *)
A=real[[1]];
B=real[[2]];
If[MatrixQ[G[s]],
     MatrixRank[appendRows @@ NestList[A . #&, B, len-1]], (* MIMO Case *)
     MatrixRank[NestList[A . #&, B, len-1]]]         (* SIMO Case *)
]
SetAttribute[McMillanDegree,ReadProtected];
SetAttribute[McMillanDegree,Locked];


(* ObservableRealization used in McMillanDegree *)
Clear[ObservableRealization];
ObservableRealization[G_,s_]:=Module[{p,A,B,C,lcd,len,coeff,list,L0,listend},
If[MatrixQ[G[s]],
        p=Dimensions[G[s]][[1]];     (* Number of outputs *)
        lcd=LeastCommonDenominator[G,s]; (* LCD of elements *)
        len=Exponent[lcd,s];               (* Highest power *)
        coeff=Drop[CoefficientList[lcd,s],-1]; (* Delete coeff s^n *)
A=BlockCompanionMatrix[coeff,p];
list=LaurentCoeff[G,s];
L0=list[[1]];
listend=Drop[list,1];
B=Fold[appendColumns,L0,listend];
C=
Transpose[Flatten[Prepend[Table[zeroMatrix[p],{len-1}],IdentityMatrix[p]],1]];
{A,B,C}, 
        (* Now the case when g[s] is a scalar *)
        lcd=LeastCommonDenominator[G,s]; (* LCD of elements *)
        len=Exponent[lcd,s];               (* Highest power *)
        coeff=Drop[CoefficientList[lcd,s],-1]; (* Delete coeff s^n *)
A=BlockCompanionMatrix[coeff,1];
B=LaurentCoeff[G,s];
C=Prepend[Table[0,{len-1}],1];
{A,B,C}
]];
SetAttribute[ObservableRealization,ReadProtected];
SetAttribute[ObservableRealization,Locked];


(*
LaurentCoeff::usage = 
"LaurentCoeff[G,s] is a list of coeff. of s^(-k), k=1,2,...,len
Laurent Series expansion of G[s] where len is the degree of the
LeastCommonDenominator polynomial of G[s].
It is used in constructing an observable realization for G[s]."
*)
Clear[LaurentCoeff];
LaurentCoeff[G_,s_]:=  
    Module[{lcd,len,powers,expand},
        lcd=LeastCommonDenominator[G,s]; (* LCD of elements *)
        len=Exponent[lcd,s];               (* Highest power *)
        powers=Table[-k,{k,1,len}];         (* List of powers *)
        expand=Normal[LaurentSeries[G,s,len]];
Map[Coefficient[expand,s^#]&,powers]];
SetAttribute[LaurentCoeff,ReadProtected];
SetAttribute[LaurentCoeff,Locked];

Clear[LaurentSeries];
LaurentSeries[G_,s_,n_?IntegerQ]:=Module[{q},
                Series[G[1/q],{q,0,n}]/.{q->1/s}];
SetAttribute[LaurentSeries,ReadProtected];
SetAttribute[LaurentSeries,Locked];


row[a_,b_,n_,m_]:=Module[{list},
                         list=Table[b,{n-1}];
                         Transpose[Flatten[Insert[list,a,m],1]]];


top[a_,b_,n_]:=Flatten[Map[row[a,b,n,#]&,Table[{i},{i,2,n}]],1];


bottom[a_,list_]:=Transpose[Flatten[Map[(a #)&,(-1 list)],1]];

Clear[BlockCompanionMatrix];
BlockCompanionMatrix[p_List, block_Integer] :=
                Module[{n = Length[p],im,zm,aa,bb},
                im=IdentityMatrix[block];
                zm=zeroMatrix[block];
                aa=top[im,zm,n];
                bb=bottom[im,p];
                Join[aa,bb]];
SetAttribute[BlockCompanionMatrix,ReadProtected];
SetAttribute[BlockCompanionMatrix,Locked];

Clear[StateSpaceToTransferFunction];
StateSpaceToTransferFunction[Amat_,Bmat_,Cmat_,s_]:=
        Module[{Dmat},
        Dmat=zeroMatrix[Dimensions[Cmat][[1]],Dimensions[Bmat][[2]]];
        StateSpaceToTransferFunction[Amat,Bmat,Cmat,Dmat,s]
    ]

StateSpaceToTransferFunction[Amat_,Bmat_,Cmat_,Dmat_,s_]:=
Module[
     {nst,nrb,ncb,nrc,ncc,nrd,ncd},
If[Not[MatrixQ[Amat]] || Not[MatrixQ[Bmat]] || 
       Not[MatrixQ[Cmat]] || Not[MatrixQ[Dmat]],
      Print["Error[TransferFunction]::Arguments must be matrices."],
      nst=Dimensions[Amat][[1]];
     {nrb,ncb}=Dimensions[Bmat];
     {nrc,ncc}=Dimensions[Cmat];
     {nrd,ncd}=Dimensions[Dmat];
If[(nrb!=nst || ncc!= nst || ncd != ncb || nrd != nrc),
     Print["Error[TransferFunction]::Matrix dimensions are incorrect"],
     Together[Dmat+Dot[Cmat,Dot[Inverse[s IdentityMatrix[nst]
                                - Amat],Bmat]]]
]]];
SetAttribute[StateSpaceToTransferFunction,ReadProtected];
SetAttribute[StateSpaceToTransferFunction,Locked];


Clear[LeastCommonDenominator];
LeastCommonDenominator[G_,s_]:=Module[{f,d,d1},
If[MatrixQ[G[s]],
Apply[PolynomialLCM,Flatten[Denominator[SimplifyArray[G[s]]]]],
PolynomialLCM[Denominator[Simplify[G[s]]]]
]];
SetAttribute[LeastCommonDenominator,ReadProtected];
SetAttribute[LeastCommonDenominator,Locked];


(*
MatrixRank[A_?MatrixQ]:= Length[SingularValueDecomposition[N[A]][[2]]];
*)
(*
MakeGain::usage = 
"MakeGain[B,port,gainvector] inserts the gain
vector computed in pole placement via a designated port (column
of B) in a zero matrix with dimensions = dimensions of Transpose[B].";
*)
Clear[MakeGain];
MakeGain[(B_)?MatrixQ,port_?IntegerQ, (k_)?VectorQ] := 
  Module[{dim}, dim = Dimensions[Transpose[B]]; 
    ReplacePart[zeroMatrix[dim[[1]], dim[[2]]], k,port]];
SetAttribute[MakeGain,ReadProtected];
SetAttribute[MakeGain,Locked];


Clear[PolePlace];
PolePlace[A_?squareMatrixQ,B_?MatrixQ,poles_?ListQ]:=
                Module[{bestport,list,condnums,portgain},
                   list=Table[
                controllabilityMatrix[A,Transpose[B][[i]]],
                        {i,1,Dimensions[B][[2]]}];
                condnums=
                Table[ConditionNumber[N[list[[i]]]],{i,1,Length[list]}];
                    bestport= ListArgMin[condnums];  (* Place the poles from
                                                   this port *)
               portgain=PortGain[A,B,bestport,poles]; (* Gain at the port *)
               MakeGain[B,bestport,portgain]];

(* Use the single input case to compute the gain vector *)

PortGain[A_?squareMatrixQ,B_?MatrixQ,port_?IntegerQ,poles_?ListQ]:=
                Module[{portgain},
                portgain= 
                    PolePlace[A,Flatten[TakeColumns[B,{port,port}]],poles]];

PolePlace[A_?squareMatrixQ,B_?MatrixQ,port_?IntegerQ,poles_?ListQ]:=
                Module[{portgain},
                portgain=
                    PolePlace[A,Flatten[TakeColumns[B,{port,port}]],poles];
               MakeGain[B,port,portgain]];

PolePlace[A_?squareMatrixQ,b_?VectorQ,poles_?ListQ]:= Module[{lengthb,gains},
  lengthb=Length[b];
  If[lengthb==1,
    gains=Inverse[controllabilityMatrix[A,b]].MatrixPolynomialRoots[poles,A],
    gains = Append[Flatten[zeroMatrix[lengthb-1,1]],1].Inverse[controllabilityMatrix[A,b]].MatrixPolynomialRoots[poles,A]
  ]; (* end If *)
  Return[gains]
];
SetAttribute[PolePlace,ReadProtected];
SetAttribute[PolePlace,Locked];

Clear[ConditionNumber];
ConditionNumber[(m_)?MatrixQ] := 
                      Module[{sv},
                           sv=SingularValueDecomposition[N[m]][[2]];
                      If[Length[sv]==Dimensions[m][[1]],
                         Last[sv]/First[sv],
                         Infinity]]
SetAttribute[ConditionNumber,ReadProtected];
SetAttribute[ConditionNumber,Locked];

Clear[ ListArgMin];
 ListArgMin[list_?ListQ] := 
      Module[{min, i}, 
                min=Min[list];
                i=0;
        While[True, i += 1; 
             If[list[[i]] === min, Return[i]; Break[]]]]
SetAttribute[ ListArgMin,ReadProtected];
SetAttribute[ ListArgMin,Locked];

Clear[ ListArgMax];
 ListArgMax[list_?ListQ] := 
      Module[{max, i}, 
                max=Max[list];
                i=0;
        While[True, i += 1; 
             If[list[[i]] === max, Return[i]; Break[]]]]
SetAttribute[ ListArgMax,ReadProtected];
SetAttribute[ ListArgMax,Locked];

(* Construct a polynomial from its roots *)
Clear[PolynomialRoots];
PolynomialRoots[roots_?ListQ,s_]:=Expand[Times @@ Map[(s-#)&,roots]];  
SetAttribute[PolynomialRoots,ReadProtected];
SetAttribute[PolynomialRoots,Locked];

(* Construct a matrix polynomial from its "roots" *)
Clear[MatrixPolynomialRoots];
MatrixPolynomialRoots[roots_?ListQ,A_?squareMatrixQ]:=Module[{dimA},
                dimA=Dimensions[A][[2]];
     Expand[Dot @@ Map[(A- # IdentityMatrix[dimA])&,roots]]]
SetAttribute[MatrixPolynomialRoots,ReadProtected];
SetAttribute[MatrixPolynomialRoots,Locked];

(* Construct a polynomial from its coefficients *)
Clear[PolynomialCoefficients];
PolynomialCoefficients[coeff_?ListQ,s_]:=Module[{lengthcoeff},
                      lengthcoeff=Length[coeff];
       Inner[Times,coeff,Table[s^(lengthcoeff-1-k),{k,0,lengthcoeff-1}],Plus]]
SetAttribute[PolynomialCoefficients,ReadProtected];
SetAttribute[PolynomialCoefficients,Locked];

(* Construct a matrix polynomial from its coefficients *)
Clear[MatrixPolynomialCoefficients];
MatrixPolynomialCoefficients[coeff_,A_?squareMatrixQ]:=
Module[{lengthcoeff,listpowers},
                               lengthcoeff=Length[coeff];
        listpowers=Table[MatrixPower[A,lengthcoeff-1-k],{k,0,lengthcoeff-1}];
                     Plus @@ ((#1 #2)& @@ {coeff,listpowers})]
SetAttribute[MatrixPolynomialCoefficients,ReadProtected];
SetAttribute[MatrixPolynomialCoefficients,Locked];

Clear[ControllablePair];
ControllablePair[a_?squareMatrixQ, b_?MatrixQ] :=
Module[{n = Dimensions[a][[1]]},
   Rank[controllabilityMatrix[a,b]]===n
] /; Dimensions[a][[2]] === Dimensions[b][[1]];

ControllablePair[a_?squareMatrixQ, b_?VectorQ] :=
Module[{n = Dimensions[a][[1]]},
   Rank[controllabilityMatrix[a,b]]===n
] /; Dimensions[a][[2]] === Length[b];
SetAttribute[ControllablePair,ReadProtected];
SetAttribute[ControllablePair,Locked];

Clear[ObservablePair];
ObservablePair[a_?squareMatrixQ, c_?MatrixQ] :=
Module[{n = Dimensions[a][[1]]},
   Rank[observabilityMatrix[a,c]]===n
]/; Dimensions[a][[2]] === Dimensions[c][[2]];

ObservablePair[a_?squareMatrixQ, c_?VectorQ] :=
Module[{n = Dimensions[a][[1]]},
   Rank[observabilityMatrix[a,c]]===n
] /; Dimensions[a][[2]] === Length[c];
SetAttribute[ObservablePair,ReadProtected];
SetAttribute[ObservablePair,Locked];

Clear[observabilityMatrix];
observabilityMatrix[a_?squareMatrixQ, c_?MatrixQ] := Module[{},
If[Not[TestDataobservabilityMatrix[a,c]],
Print["Error[observabilityMatrix]::Data dimensions are incorrect"],
  ArrayFlatten[Transpose[{NestList[#.a &, c, Length[a] - 1]}]]]];

observabilityMatrix[a_?squareMatrixQ, c_?VectorQ] := Module[{},
If[Not[TestDataobservabilityMatrix[a,c]],
Print["Error[observabilityMatrix]::Data dimensions are incorrect"],
                   NestList[# . a&, c, Length[a]-1]]];
SetAttribute[observabilityMatrix,ReadProtected];
SetAttribute[observabilityMatrix,Locked];

Clear[TestDataobservabilityMatrix];
TestDataobservabilityMatrix[a_?squareMatrixQ, b_?VectorQ] := Module[{da,db},
                da=Dimensions[a][[2]];
                db=Length[b];
                If[da==db,True,False]];

TestDataobservabilityMatrix[a_?squareMatrixQ, b_?MatrixQ] := Module[{da,db},
                da=Dimensions[a][[2]];
                db=Dimensions[b][[2]];
                If[da==db,True,False]];
SetAttribute[TestDataobservabilityMatrix,ReadProtected];
SetAttribute[TestDataobservabilityMatrix,Locked];

Clear[controllabilityMatrix];
controllabilityMatrix[a_?squareMatrixQ, b_?MatrixQ] := Module[{},
If[Not[TestDatacontrollabilityMatrix[a,b]],
Print["Error[controllabilityMatrix]::Data dimensions are incorrect"],
      ArrayFlatten[{NestList[a.# &, b, Length[a] - 1]}]]];
(* controllabilityMatrix for the case when the B "matrix" is a vector *)
controllabilityMatrix[a_?squareMatrixQ, b_?VectorQ] := Module[{},
If[Not[TestDatacontrollabilityMatrix[a,b]],
Print["Error[controllabilityMatrix]::Data dimensions are incorrect"],   
                    Transpose[NestList[a . #&, b, Length[a]-1]]]];
SetAttribute[controllabilityMatrix,ReadProtected];
SetAttribute[controllabilityMatrix,Locked];

Clear[TestDatacontrollabilityMatrix];
TestDatacontrollabilityMatrix[a_?squareMatrixQ, b_?VectorQ] := Module[{da,db},
                da=Dimensions[a][[2]];
                db=Length[b];
                If[da==db,True,False]];
TestDatacontrollabilityMatrix[a_?squareMatrixQ, b_?MatrixQ] := Module[{da,db},
                da=Dimensions[a][[2]];
                db=Dimensions[b][[1]];
                If[da==db,True,False]];
SetAttribute[TestDatacontrollabilityMatrix,ReadProtected];
SetAttribute[TestDatacontrollabilityMatrix,Locked];


Unprotect[jacobian];
jacobian[f_List, x_List] := Outer[D, f, x]
Protect[jacobian];

Clear[TaylorLinearize];
TaylorLinearize[F_?MatrixQ,f_List, g_List, x_List, x0_List, u_List, u0_List] :=
        Join[{F/.Thread[x -> x0]},TaylorLinearize[f,g,x,x0,u,u0]];
TaylorLinearize[f_List, g_List, x_List, x0_List, u_List, u0_List] :=
         TaylorLinearize[f, g, x, u]/.
         Flatten[{Thread[x -> x0], Thread[u -> u0]}];
TaylorLinearize[f_List, g_List, x_List, u_List] :=
{jacobian[f, x], jacobian[f, u], jacobian[g, x], jacobian[g, u]
            } /; (Length[f] === Length[x] );
SetAttribute[TaylorLinearize,ReadProtected];
SetAttribute[TaylorLinearize,Locked];

Format[LinearSystem[x__ ]] := 
   ColumnForm[ MatrixForm /@ {x} ];

Clear[SystemForm];
SystemForm[LinearSystem[a_, b_, c_, d_]] := Block[{xeqn,yeqn},
 xeqn= ColumnForm[ a . Array["x", {Length[a]}] ] + 
 ColumnForm[ b . Array["u", {Length[Transpose[b]]} ]] ;

 yeqn= ColumnForm[ c . Array["x", {Length[Transpose[c]]}] ] + 
 ColumnForm[ d . Array["u", {Length[d]}] ];
 Return[ColumnForm[{xeqn," ",yeqn}]]
];
SetAttribute[SystemForm,ReadProtected];
SetAttribute[SystemForm,Locked];

Clear[RandomMatrix];
RandomMatrix[n_Integer,m_Integer]:=
                     Table[Random[],{n},{m}]-Table[Random[],{n},{m}];
RandomMatrix[n_Integer]:=RandomMatrix[n,n];
SetAttribute[RandomMatrix,ReadProtected];
SetAttribute[RandomMatrix,Locked];


(************************************************************************)
(*                      Minimal Realization                             *)
(************************************************************************)

Clear[MinimalRealization];
MinimalRealization[G_,s_]:=
  Module[{GG,PFE,factors,AA={},BB={},CC={},DD,A,B,H},
		(* partial fraction expansion *)
		GG[x_]:=Rationalize[G[x]];
		PFE=Apart[GG[s],s];
		factors=Drop[FactorList[LeastCommonDenominator[GG,s]],1];
		Do[
		{A,B,H}=CreateJordanBlock[PFE,factors[[i]],s];
		AA=DiagJoin[AA,A];
		BB=Join[BB,B];
		CC=Join[CC,H]
		,{i,Length[factors]}];
		DD=GG[Infinity];
		{AA,BB,Transpose[CC],DD}
      ]
MinimalRealization[AA_,BB_,CC_,DD_]:=Module[{A1,B1,C1,D1,T},
		{A1,B1,C1,D1}=
      KalmanDecomposition[AA,BB,CC,DD,IrreducibleRealization->True];
		{T,A1}=JordanDecomposition[A1];
		B1=LinearSolve[T,B1];
		C1=C1.T;
		{A1,B1,C1,D1}
		]
SetAttribute[MinimalRealization,ReadProtected];
SetAttribute[MinimalRealization,Locked];
      
Clear[CreateJordanBlock];
CreateJordanBlock[PFE_,factor_List,s_]:=
  Module[{CoefficientList,BList,	AA={},BB={},CC={},A,B,p,CCT,kk,DD,EE,TT},
		CoefficientList=
      Map[Coefficient[PFE,1/factor[[1]]^#]&,Reverse[Range[factor[[2]]]]];
		BList=Map[QRDecomposition[#][[2]]&,CoefficientList];
		BList=Flatten[BList,1];
		BList=DropLastZeroRows[RowReduce[BList]];
		p=s/.Solve[factor[[1]]==0,s][[1]];
		Do[CCoefficients=
        	Map[CoefficientList[[#]].BList[[i]]&,Range[Length[CoefficientList]]];
		  	CCoefficients=DropFirstZeroRows[CCoefficients];
			{A,B}=JordanBlock[p,Length[CCoefficients],BList[[i]]];
			AA=DiagJoin[AA,A];
			BB=Join[BB,B];
			CC=Join[CC,CCoefficients]
			,{i,Length[BList]}];
		CCT=Transpose[CC];
		If[Not[ObservablePair[AA,CCT]],Print["Eliminating nonobservable states."];
			DD=SpanD[observabilityMatrix[AA,CCT]];
			EE=NullSpace[DD];
			TT=Join[DD,EE];
			AA=Transpose[LinearSolve[Transpose[TT],Transpose[TT.AA]]];
			BB=TT.BB;
			CC=DropLastZeroRows[LinearSolve[Transpose[TT],CC]];
			kk=Length[CC];
			AA=AA[[Range[kk],Range[kk]]];
			BB=BB[[Range[kk]]];
			];
	  {AA,BB,CC}
     ]
SetAttribute[CreateJordanBlock,ReadProtected];
SetAttribute[CreateJordanBlock,Locked];
      
Clear[JordanBlock];
JordanBlock[p_,n_Integer,b_?VectorQ]:=Module[{A={},BB={}},
		If[n===0,Return[A]];
		If[n===1,A={{p}};Return[{A,{b}}]];
		A={Flatten[Append[{{p,1}},Table[0,{n-2}]]]};
		BB=Prepend[{b},Table[0,{Length[b]}]];
	 	Do[
			A=If[i<=n-2,Append[A,RotateRight[A[[-1]]]],A];
			BB=Prepend[BB,Table[0,{Length[b]}]];
		  ,{i,1,n-2}];
		 A=Append[A,Append[Table[0,{n-1}],p]];
		{A,BB}
      ]
SetAttribute[JordanBlock,ReadProtected];
SetAttribute[JordanBlock,Locked];


(************************************************************************)
(*                      Kalman Decomposition                            *)
(************************************************************************)

Clear[ObservableDecomposition];
ObservableDecomposition[AA_,BB_,CC_,DD_]:=
  Module[{OS,EE,TT,AAnew,BBnew,CCnew},
	If[Rationalize[Flatten[CC].Flatten[CC]]===0,Return[{AA,BB,CC,DD}]];
	OS=SpanD[observabilityMatrix[AA,CC]];
	If[Length[OS]===Length[AA],Print["System is observable."];
      Return[{AA,BB,CC,DD}]];
	EE=NullSpace[OS];
	TT=Join[EE,OS];
	AAnew=Transpose[LinearSolve[Transpose[TT],Transpose[TT.AA]]];
	BBnew=TT.BB;
	CCnew=Transpose[LinearSolve[Transpose[TT],Transpose[CC]]];
	Chop[{AAnew,BBnew,CCnew,DD}]
   ]
SetAttribute[ObservableDecomposition,ReadProtected];
SetAttribute[ObservableDecomposition,Locked];
      
Clear[ControllableDecomposition];
ControllableDecomposition[AA_,BB_,CC_,DD_]:=
  Module[{CS,EE,TT,AAnew,BBnew,CCnew},
	If[Rationalize[Flatten[BB].Flatten[BB]]===0,Return[{AA,BB,CC,DD}]];
	CS=SpanD[Transpose[controllabilityMatrix[AA,BB]]];
	If[Length[CS]===Length[AA],Print["System is controllable."];
      Return[{AA,BB,CC,DD}]];
	EE=NullSpace[CS];
	TT=Transpose[Join[CS,EE]];
	AAnew=LinearSolve[TT,AA.TT];
	BBnew=LinearSolve[TT,BB];
	CCnew=CC.TT;
	Chop[{AAnew,BBnew,CCnew,DD}]
   ]
SetAttribute[ControllableDecomposition,ReadProtected];
SetAttribute[ControllableDecomposition,Locked];
      
Clear[KalmanDecomposition];
KalmanDecomposition[AA_,BB_,CC_,DD_,opts___]:=
  Module[{Ac,Bc,Cc,Dc,n=Length[AA],m=Dimensions[BB][[2]],p=Length[CC],kk,kir,
      Ac11,Ac12,Ac21,Ac22,Bc1,Bc2,Ao,Bo,Co,Do,Aco,Bco,Cco,Dco,Cc1,Cc2,Aoc,Boc,
      Coc,Doc,Cir,AAnew,BBnew,CCnew,DDnew},
		{Ac,Bc,Cc,Dc}=ControllableDecomposition[AA,BB,CC,DD];
		Print["Decompose into controllable/uncontrollable parts."];
		kk=Length[DropLastZeroRows[Bc]];
		{Ac11,Ac12,Ac21,Ac22}=	{Ac[[Range[kk],Range[kk]]],
        Ac[[Range[kk],Range[kk+1,n]]],Ac[[Range[kk+1,n],Range[kk]]],
        Ac[[Range[kk+1,n],Range[kk+1,n]]]};
		{Bc1,Bc2}={Bc[[Range[kk]]],Bc[[Range[kk+1,n]]]};
		Print["Divide controllable part into observable/unobservable parts."];
		{Ao,Bo,Co,Do}=
      ObservableDecomposition[Ac11,
        Transpose[Join[Transpose[Ac12],Transpose[Bc1]]],
        Cc[[Range[p],Range[kk]]],Dc];
		If[(IrreducibleRealization/.{opts})/.{IrreducibleRealization->False},
      Cir=DropFirstZeroRows[Transpose[Co]];kir=Length[Cir];
      Return[{appendRows[Ao,Bo[[Range[kk],Range[1,n-kk]]]][[Range[kir],
          Range[kir]]],Bo[[Range[kir],Range[n-kk+1,m+n-kk]]],
          Transpose[Cir],Do}]];
		{Aco,Bco,Cco,Dco}={appendRows[Ao,Bo[[Range[kk],Range[1,n-kk]]]],
        Bo[[Range[kk],Range[n-kk+1,m+n-kk]]],Co,Do};
		{Cc1,Cc2}={Cco[[Range[p],Range[kk]]],Cc[[Range[p],Range[kk+1,n]]]};
		Print["Divide uncontrollable part into observable/unobservable parts."];
		{Aoc,Boc,Coc,Doc}=ObservableDecomposition[Ac22,Bc2,Cc2,Dco];
	  	Anew=BlockMatrix[{{Aco},{Ac21,Aoc}}];
		Bnew=appendColumns[Bco,Boc];
		Cnew=appendRows[Cc1,Coc];
		Dnew=Doc;
	Chop[{Anew,Bnew,Cnew,Dnew}]
   ]
SetAttribute[KalmanDecomposition,ReadProtected];
SetAttribute[KalmanDecomposition,Locked];

(************************************************************************)
(*                      MyInverse                                       *)
(************************************************************************)
(*  Finds the inverse symbolically, then substitutes the elements of the *)
(*    original matrix                                                   *)


Clear[MyInverse];

MyInverse[A_?MatrixQ]:=Module[{
mat,            (* matrix of symbolic terms of same size as A*)
a,              (* a[i,j] are elements of mat *)
Inv,            (* inverse[mat] *)
ElemsA,         (* List of elements of A *)
ZeroElemsA,     (* positions of the zero elements of A *)
NonZeroElemsA,  (* Complement of ZeroElemsA*)
ZeroRule,       (* Rule to substitute the zero elements first *)
NonZeroRule     (* Rule to substitute the rest of the elements *)
},
mat=Table[a[i,j], {i,Dimensions[A][[1]]},{j,Dimensions[A][[2]]}];
ElemsA=Flatten[A];
ZeroElemsA=Flatten[Position[ElemsA,0]];
NonZeroElemsA=Complement[Range[Length[ElemsA]],ZeroElemsA];
ZeroRule=Thread[Flatten[mat][[ZeroElemsA]]->ElemsA[[ZeroElemsA]]];
NonZeroRule=Thread[Flatten[mat][[NonZeroElemsA]]->ElemsA[[NonZeroElemsA]]];
Inv=Inverse[mat/.ZeroRule];
Inv/.NonZeroRule
]
SetAttribute[MyInverse,ReadProtected];
SetAttribute[MyInverse,Locked];


(* Right Inverse *)
RightInverse[A_?MatrixQ]:=Module[{m,n,test,
  Id,B,DD,DD1,DD2,ZeroRow,G,IndexSet,XX,row,RowNo},
  {m,n}=Dimensions[A];
  Id=IdentityMatrix[m];
  B=Transpose[Join[Transpose[A],Id]];
  DD=RowReduce[B];
  DD1=DD[[Range[1,m],Range[1,n]]];
  DD2=DD[[Range[1,m],Range[n+1,n+m]]];
  {ZeroRow}=Table[0,{1},{m}];
  G=Position[DD1,1];
  IndexSet={};RowNo=1;
   Do[(If[G[[j,1]]==RowNo,
          IndexSet=Append[IndexSet,G[[j,2]]];
          RowNo=RowNo+1
         ]
   ),{j,Length[G]}];
   XX={};row=1;
   Do[(If[Intersection[{j},IndexSet]=={},
          XX=Append[XX,ZeroRow],
          XX=Append[XX,DD2[[row]]];row=row+1;
         ]
   ),{j,n}];
  XX
]

(*Left Inverse *)
LeftInverse[A_?MatrixQ]:=Module[{B,XX},
  B=Transpose[A];
  XX=Transpose[RightInverse[B]]
]

(************************************************************************)
(*                      HamiltonianMatExp                                       *)
(************************************************************************)
(*  Finds the resolvent and then takes the inverse laplace transform *)

Clear[MyMatrixExp];
MyMatrixExp[A_,t_]:=Module[{n,s,B},
    n=Length[A];
    B=MyInverse[s*IdentityMatrix[n]-A];
    InverseLaplaceTransform[B[[ Range[1,n],Range[1,n] ]],s,t]
]
SetAttribute[MyMatrixExp,ReadProtected];
SetAttribute[MyMatrixExp,Locked];

Clear[HamiltonianMatExp];
HamiltonianMatExp[A_,t_]:=Module[{n,s,B,lcd,bb,NumB,Num,eigs},
    n=Length[A];
    B[x_]:=MyInverse[x*IdentityMatrix[n]-A];
    lcd=Det[s*IdentityMatrix[n]-DiagonalMatrix[Eigenvalues[A]]];
    bb=InverseLaplaceTransform[1/lcd,s,t];
    Num=Expand[Cancel[lcd*B[s][[ Range[1,n],Range[1,n/2] ]]],s];
    NumB[f_,x_]:=(Num/.{s^m_?IntegerQ->D[f,{x,m}]})/.{s->D[f,x]};
    NumB[bb,t]+(Num/.s->0)*(bb-1)
]
SetAttribute[HamiltonianMatExp,ReadProtected];
SetAttribute[HamiltonianMatExp,Locked];

(* 
EigSort returns a list of sorted eigenvalues in increasing
real part, and a list of corresponding indices.
*)
Clear[EigSort];
EigSort[Eigs_]:=Module[{ReEigs,SE,F,IndexList},
    ReEigs=Re[N[Eigs]];
    SE=Union[Sort[ReEigs]];
    F[x_]:=Position[ReEigs,x];
    IndexList=Flatten[Map[F,SE]];
    {Eigs[[IndexList]],IndexList}
    ]
SetAttribute[EigSort,ReadProtected];
SetAttribute[EigSort,Locked];

Clear[InvAB];
InvAB[A_,B_]:=LinearSolve[A,B];
SetAttribute[InvAB,ReadProtected];
SetAttribute[InvAB,Locked];

Clear[BInvA];
BInvA[A_,B_]:=Transpose[LinearSolve[Transpose[A],Transpose[B]]];
SetAttribute[BInvA,ReadProtected];
SetAttribute[BInvA,Locked];

Clear[DropFirstZeroRows];
DropFirstZeroRows[XX_]:=
If[Rationalize[XX[[1]].XX[[1]]]===0,DropFirstZeroRows[Drop[XX,1]],XX]
   
Clear[DropLastZeroRows];
DropLastZeroRows[XX_]:=
	If[Rationalize[XX[[-1]].XX[[-1]]]===0,DropLastZeroRows[Drop[XX,-1]],XX]
         
Clear[DiagJoin];
DiagJoin[A_,B_]:=Module[{ma,na,mb,nb,Zilch,H0,H1,X},(
                 If[A=={},X=B,(
                 {ma,na}=Dimensions[A];{mb,nb}=Dimensions[B];
                 Zilch=Table[0,{mb},{na}];H0=Join[A,Zilch];
                 Zilch=Table[0,{ma},{nb}];H1=Join[Zilch,B];
                 X=Transpose[Join[Transpose[H0],Transpose[H1]]])];
                 X
                 )];


Print["  *** LinearControl successfully loaded ***"];
End[];        (* end the private context *)

Protect[ControllableDecomposition,ObservableDecomposition];


(****************************************************************)
(*                      Utitlity Functions                      *)
(****************************************************************)





EndPackage[];  (* end the package context *)
If[!spell1, On[General::spell1]];
If[!spell, On[General::spell]];

