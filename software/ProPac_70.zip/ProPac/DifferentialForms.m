(* ::Package:: *)

(*                DifferentialForms


           Techno-Sciences, Inc.
           10001 Derekwood Lane, Suite 204
           Lanham, MD 20706
           (301) 577-6000
           
           
Copyright \[Copyright] 1997, 1998, 2000 Techno-Sciences Incorporated
All Rights Reserved          
           
*)
spell1 = (Head[General::spell1] === $Off);
spell = (Head[General::spell] === $Off);
Off[General::spell1];
Off[General::spell]; 



BeginPackage["ProPac`DifferentialForms`",{"ProPac`GeoTools`"}]

(* ********************************************************************** *)
(* ********************************************************************** *)
DifferentialForms::usage="
Functions Provided are:\n
\n
Forms:\n
\n
Contraction, d, FormBasis, FormDegree, FormQ,\n 
FormSimplify, RankCodistribution, Wedge.\n
"

(* Function Usage Statements *)

FormDegree::usage = "
FormDegree[w] returns the degree of the differential form w.
"
d::usage = "
d[w] is the exterior derivative operator that acts on k-forms w.
"
Wedge::usage = "
Wedge[v,w,..] returns the wedge product of the forms v, w,...
"
FormBasis::usage = "
FormBasis[W,x] returns a basis for the list of forms W in the \n
coordinates x.
"
Contraction::usage = "
Contraction[w,v,x] returns the contraction of the form w with the\n
vector v. x is the vector of coordinates.
"
FormQ::usage = "
FormQ[w] returns True if w is a form. Otherwise it returns False.
"
FormSimplify::usage = "
FormSimplify[w] returns w as a sum of simple forms with factored\n
scalar coefficients.
"

RankCodistribution::usage = "
RankCodistribution[W,coords] returns the Rank of the codistribution W\n
(a list of 1-forms) in the coordinates coords.
"

(* ****** Options ****** *)



(* ****************************************************** *)

(*  Functions *)

Begin["`private`"]

(* ****************************************************** *)

Clear[FormDegree]
FormDegree[d[x_]] := 1 + FormDegree[x];
FormDegree[x_\[Wedge]z___] := FormDegree[x] + 
          FormDegree[Wedge[z]];
FormDegree[Wedge[x_ /; MemberQ[HeadList, Head[x]]]] := 
        FormDegree[x];
FormDegree[x_ + y_] := FormDegree[x]; 
FormDegree[Times[x_^n_. , y__]] := FormDegree[x] + 
        Plus @@ Map[FormDegree, {y}];
FormDegree[x_] := 
        Which[MemberQ[{NullTest}, x], 1, True, 0];
        
(* ****************************************************** *)

Clear[FormQ]
HeadList = {d, Symbol};
FormQ[x_] := 
  Head[x]=!=List && Cases[x, d[_], Infinity] =!= {} && 
      If[Head[x] === Plus, 
        Inner[SameQ, Map[FormDegree[#] &, Level[x, 1]], 
          Map[FormDegree[#] &, RotateLeft[Level[x, 1], 1]], And], True] || 
    Head[x] === d
BasicFormQ[x_] := Head[x] === d

(* ****************************************************** *)

Clear[d]
SetAttributes[d, {Listable}];
d[x_ + y_] := d[x] + d[y]; 
d[x_\[Wedge]y__] := 
        d[x]\[Wedge]y + (-1)^FormDegree[x] x\[Wedge]d[Wedge[y]]; 
d[x_*y_] := 
        d[x]\[Wedge]y + (-1)^FormDegree[x] x\[Wedge]d[y]; 
d[d[_]] := 0; 
d[x_ /; NumberQ[x] || MemberQ[const, x]] := 0;
d[x_ /; Element[x, Complexes]] := 0;
d[Power[y_, n_]] := n y^(n - 1) d[y];
d[Exp[x_]]:=Exp[x] d[x];
d[Wedge[x_ /; MemberQ[HeadList, Head[x]]]] := d[x]; 
d[g_] := Sum[D[g, g[[i]]] d[g[[i]]], {i, Length[g]}] /; 
          FormDegree[g] === 0 &&Depth[g] > 1 && ! NumberQ[g[[1]]];

(*
LieDerivative1[f_?VectorQ,w_?FormQ,x_?VectorQ]:=FormSimplify[Sum[Jacob[\
Coefficient[w,d[x[[i]]]],x].f d[x[[i]]] + Sum[Coefficient[w,d[x[[j]]]] \
D[f[[j]],x[[i]]],{j,Length[x]}] d[x[[i]]],{i,Length[x]}]]/;FormDegree[w]===1;
LieDerivative1[f_?VectorQ,0,x_?VectorQ]:=0;
*)

(* ****************************************************** *)

Clear[CoordBasis]
CoordBasis = d[g_Symbol] :> 
            0 /; Head[CoordName] === List && ! MemberQ[CoordName, g];

            
(* ****************************************************** *)

Clear[Wedge]            
Default[Wedge] := 1; 
SetAttributes[Wedge, {Flat, OneIdentity}];
Wedge[x_ + y_, z__] := Wedge[x, z] + Wedge[y, z];
Wedge[x__, y_ + z_] := Wedge[x, y] + Wedge[x, z];
Wedge[u___, Times[x_^n_. , y_],z___]:= Times[x^n, Wedge[u, y, z]] /; \
FormDegree[x] === 0;
x_^n_. \[Wedge]y_ := x^n*y/; FormDegree[x] === 0;
y_\[Wedge]x_^n_. := x^n*y/; FormDegree[x] === 0;
Wedge[x_, y___, x_] := 0 /; FormDegree[x] === 1;
x_\[Wedge]y_ := (-1)^(FormDegree[x]*FormDegree[y])*y\[Wedge]x/; \
BasicFormQ[x]&& BasicFormQ[
      y]&&(FormDegree[x]> \
FormDegree[y]||(FormDegree[x]===FormDegree[y]&&!OrderedQ[{x,y}])); 
Wedge[Times[x_, y_]] := Times[x, y];
Wedge[Plus[x_, y_]] := Plus[x, y];

(* ****************************************************** *)

Clear[Contraction]
Default[Contraction] := 1; 
SetAttributes[Contraction, {Flat, OneIdentity}]; 
Contraction[a_ x_, y_?VectorQ, coords_?VectorQ] := 
        a Contraction[x, y, coords]/;FormDegree[a] === 0; 
Contraction[x_, a_ y_?VectorQ, coords_?VectorQ] := 
        a Contraction[x, y, coords]/;FormDegree[a] === 0; 
Contraction[x_ + y_, z_?VectorQ, coords_?VectorQ] :=   Contraction[x, z, \
coords] + Contraction[y, z, coords]; 
Contraction[x_, y_ + z_?VectorQ, coords_?VectorQ] := 
        Contraction[x, y,coords] + Contraction[x, z,coords]; 
Contraction[d[x_], y_?VectorQ, coords_?VectorQ] := 
        y[[Position[coords, x][[1, 
                  1]]]]/; 
FormDegree[x] === 0 \
&&Intersection[{x},coords] =!= {}; 
Contraction[d[x_]\[Wedge]d[z_], y_?VectorQ, coords_?VectorQ] := 
        Det[Transpose[{{y[[Position[coords,x][[1, 1]]]], 
                  y[[Position[coords,z][[1, 1]]]]}, {d[x], 
                  d[z]}}]] /; 
FormDegree[x] === 0 && 
            Intersection[{x}, coords] =!= {} && FormDegree[z] === 0 && 
            Intersection[{z}, coords] =!= {};
Contraction[w_, y_?VectorQ, coords_?VectorQ] := Module[{Diffs, \
m=FormDegree[w],WedgeList,Usedcoords},
      Diffs=Level[w, {1}];
      Usedcoords=Level[w, {2}];
WedgeList = \
Map[If[m>2,Apply[Wedge,Drop[Diffs,{#}]],Drop[Diffs,{#}][[1]]]&,Range[m]];
Sum[(-1)^(k+1) y[[Position[coords,Usedcoords[[k]]][[1,1]]]] \
WedgeList[[k]],{k,m}]

] /;Inner[SameQ, Map[FormDegree[#]&, Level[w, {1}]], 
            Table[1, {Length[Level[w, {1}]]}],And]&&FreeQ[
            Map[MemberQ[coords, #]&, Level[w, {2}]], 
            False]
         
(* ****************************************************** *)

Clear[FormSimplify]
SetAttributes[FormSimplify, {Listable}]; 
FormSimplify[x_] := Collect[Together[x /. {Cos[_]^2 + Sin[_]^2 -> 1}], \
   {Wedge[_], d[_]}, Factor] /. {Cos[_]^2 + Sin[_]^2 -> 1};

(* ****************************************************** *)

Clear[FormBasis]
FormBasis[W_,Coords_]:=Module[{m=FormDegree[W[[1]]],coords=Sort[Coords],n=\
Length[Coords],Diffs,Indices,WedgeList,VecList,Basis},

Diffs = Map[ToExpression["d["<>ToString[#]<>"]"]&, \
coords];

Indices = Permutations[Join[Table[1, {m}], Table[0, {n - \
m}]]];
WedgeList = \
If[m===1,Diffs,Map[Apply[Wedge,Diffs[[Flatten[Position[#,1]]]]]&,Indices]];
VecList = SpanD[Transpose[Map[Coefficient[W,#]&,WedgeList]]];
Basis = VecList.WedgeList
]/;W!={}&&FormDegree[W[[1]]]!=0&&Inner[SameQ,Map[FormDegree[#]&,W],Table[\
FormDegree[W[[1]]],{Length[W]}],And];
FormBasis[W_,coords_]:=FormBasis[Drop[W,Position[W,0][[1]]],coords]/;Inner[\
SameQ,W,Table[0,{Length[W]}],Or];
FormBasis[{},coords_]:={};

(* ****************************************************** *)

Clear[RankCodistribution]
RankCodistribution[W_,coords_]:=Length[FormBasis[W,coords]]

(* ****************************************************** *)


Protect[FormDegree, d, Wedge, FormBasis, Contraction, FormQ, FormSimplify,
   RankCodistribution];


(* ********************************************************************** *)
(* ********************************************************************** *)

(* ********************************************************************** *)
(* ********************************************************************** *)



End[]
EndPackage[ ]

(* ********************************************************************** *)
(* ********************************************************************** *)
If[!spell1, On[General::spell1]];
If[!spell, On[General::spell]];
