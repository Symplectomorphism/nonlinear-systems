(* ::Package:: *)

(*                VSCTools

           
Copyright \[Copyright] 2017 H. G. Kwatny.
All Rights Reserved          
           
*)
spell1 = (Head[General::spell1] === $Off);
spell = (Head[General::spell] === $Off);
Off[General::spell1];
Off[General::spell]; 

If[$VersionNumber===2.,BeginPackage["ProPac`VSCTools`",{"ProPac`ControlL`","ProPac`ControlN`",
      "ProPac`NDTools`","LinearAlgebra`MatrixManipulation`","Calculus`DiracDelta`"}]];
If[$VersionNumber===3.,BeginPackage["ProPac`VSCTools`",{"ProPac`ControlL`","ProPac`ControlN`",
      "ProPac`NDTools`","LinearAlgebra`MatrixManipulation`","Calculus`DiracDelta`"}]];
If[$VersionNumber>=4.,BeginPackage["ProPac`VSCTools`",{"ProPac`ControlL`","ProPac`ControlN`",
      "ProPac`NDTools`"}]];
(* ********************************************************************** *)
(* ********************************************************************** *)


(* Function Usage Statements *)

SlidingSurface::usage="The calling syntax 
  {rho,z,s}=SlidingSurface[f,g,h,x,dec] 
returns the decoupling parameters rho, alpha, vro, and z as well as the sliding surface s. 
s is returned as a list of expressions in the state variables x. f,g,h define the square system, 
i.e. Cols[g]=Rows[h]=m, the number of inputs and outputs. dec is a positive numbers that specifies 
the minimal desired exponential decay rate also known as a 'degree of stability' for the system. 
It is also admissable to specify dec as an list of m positive numbers. This assigns 
a distinct degree of stability to each of the m chains associated with the m outputs.

The calling syntax
  s=SlidingSurface[rho,vro,z,lam]
is convenient if the decoupling matrix rho and the normal coordinates z have already been computed. 
In this case, since the vector relative degree vro has also been computed it is possible to specify  
all of the sliding poles. lam is a list of m lists defining m sets of poles - one set for each 
sliding surface. The number of poles in each list must conform to vro. That is, the number of  
specified poles should be one less than the corresponding index.
"

SwitchingControl::usage="The variable structure controller is obtained 
with the calling syntax: 
  control=SwitchingControl[rho,s,bounds,Q]  
where rho is the decoupling matrix, s is the vector of switching surfaces, bounds is a list of  
controller bounds each in the form {lower bound, upper bound}, Q is an mxm positive definite  
matrix (a design parameter), and opts are options which allow the inclusion of smoothing and/or  
moderating functions in the control. (see SmoothingFunctions and ModerationFunctions) 
The alternative syntax
  control=SwitchingControl[alpha,rho,s,bounds,Q]  
produces a control that removes the alpha terms: control=-(rho^-1)alpha+vsc. 
The calling syntax 
  control=SwitchingControl[rho,s,bounds,Q,eps]  
or  
  control=SwitchingControl[alpha,rho,s,bounds,Q,eps]  
where eps is a list of m numbers 0<eps_i<1, replaces each discontinuous switching function sign[s]  
by a smooth switching function of the form Tanh[s/eps]. 
In addition the syntax  
  control=SwitchingControl[rho,s,bounds,Q,eps,eta]  
or 
  control=SwitchingControl[alpha,rho,s,bounds,Q,eps,eta]  
where eta>1 adds a moderating function of the form Norm[z]/(eta+Norm[z]) as a control multiplier. 
 Thus, the switching bounds reduce by a factor 1/eta as z->0.
"

(*  Functions *)

Begin["`private`"]

Clear[SlidingSurface];
SlidingSurface[rho_?MatrixQ,vro_?VectorQ,z_?VectorQ,lam_List]:=Module[
    {Func,Klist,s},
    (* argument tests *)
    (* compatible dimensions of vro and lam *)
    Func[Xvro_,Xlam_]:=Module[{A,b,c},
       {A,b,c}=NormalAbc[Xvro-1];
       If[A=={{}},{1},Join[Flatten[PolePlace[A,b,Xlam]],{1}]]
             ]; (* end module Func *)
    Klist=MapThread[Func,{vro,lam}];
    s=Klist.z
    ]   

SlidingSurface[f_,g_,h_,x_,decay_]:=Module[{rho,alpha,vro,control,
        z,Func,Klist,s,temp},
                (* argument tests *)
        If[Length[f]!=Length[x],Print["Incompatible state and dynamics"];Return[]];
        If[Length[f]!=Length[g],Print["Incompatible f and g"];Return[]];
        If[Length[h]!=If[VectorQ[g],1,Dimensions[g][[2]]],Print["System must be square"];Return[]];
        temp=IOLinearize[f,g,h,x];
        If[Length[temp]!=4,Return[],{rho,alpha,vro,control}=temp];
        z=NormalCoordinates[f,h,x,vro];
        Func[Xvro_,Xlam_]:=Module[{A,b,c},
             {A,b,c}=NormalAbc[Xvro-1];
             If[A=={{}},{{1}},-ExponentialRegulator[N[A],b,c,Xlam]]
             ]; (* end module Func *)
        Klist = Map[Join[Func[#,decay][[1]],{1}]&, vro];
        s=Klist.z;
        {rho,z,s}
        ]
             
SlidingSurface[f_,g_,h_,x_,lam_List]:=Module[{rho,alpha,vro,control,
        z,Func,Klist,s,temp},
                (* argument tests *)
        If[Length[f]!=Length[x],Print["Incompatible state and dynamics"];Return[]];
        If[Length[f]!=Length[g],Print["Incompatible f and g"];Return[]];
        If[Length[h]!=If[VectorQ[g],1,Dimensions[g][[2]]],Print["System must be square"];Return[]];
        temp=IOLinearize[f,g,h,x];
        If[Length[temp]!=4,Return[],{rho,alpha,vro,control}=temp];
        z=NormalCoordinates[f,h,x,vro];
        Func[Xvro_,Xlam_]:=Module[{A,b,c},
             {A,b,c}=NormalAbc[Xvro-1];
             If[A=={{}},{{1}},appendRows[-ExponentialRegulator[N[A],b,c,Xlam],{{1}}]]
             ]; (* end module Func *)
        Klist = Flatten[MapThread[Func, {vro, lam}], 1];
        s=ProdVp[Klist,z];
        {rho,s}
        ]
SetAttributes[SlidingSurface,ReadProtected];
SetAttributes[SlidingSurface,Protected];
SetAttributes[SlidingSurface,Locked];

Clear[SwitchingControl];
SwitchingControl[rho_?MatrixQ,z_List,s_,bounds_,Q_]:=Module[{sstar,
          control},
     sstar=Transpose[rho].Q.s;
     control=Map[(bounds[[#,1]]*UnitStep[sstar[[#]]]
             +bounds[[#,2]]*UnitStep[-sstar[[#]]])&,Range[1,Length[bounds]]];
     control=UnitStep2Sign[control];
     {control,sstar}
      ]    
 
SwitchingControl[rho_?MatrixQ,z_List,s_,bounds_,Q_,eps_List]:=Module[{sstar,
          control,control1,control2,SmoothingList,SmoothingRules,SmoothFuncs,SmoothList,
          ModeratingList,ModeratingRules,ModeratingFuncs,ModerateList,F},
     {control,sstar}=SwitchingControl[rho,z,s,bounds,Q];
     F[x_,ep_]:=Tanh[x/eps];
                    (* Apply smoothing *)
     SmoothFuncs=MapThread[F[#1,#2]&,{sstar,eps}];
     SmoothingList=Inner[Times,Table[Sign[sstar[[i]]],{i,Length[s]}],
                                   SmoothFuncs,List]; 
     SmoothingRules=
                 Inner[Rule,Table[Sign[sstar[[i]]],{i,Length[s]}],SmoothingList,List];
     control1=MapThread[((#1)/.#2)&,{control,SmoothingRules}];
     control1
     ]         

SwitchingControl[rho_?MatrixQ,z_List,s_,bounds_,Q_,eps_List,alph_]:=Module[{sstar,
          control,control1,control2,SmoothingList,SmoothingRules,SmoothFuncs,SmoothList,
          ModeratingList,ModeratingRules,ModeratingFuncs,ModerateList,F,G},
     {control,sstar}=SwitchingControl[rho,z,s,bounds,Q];
     F[x_,ep_]:=Tanh[x/eps];
                    (* Apply smoothing *)
     SmoothFuncs=MapThread[F[#1,#2]&,{sstar,eps}];
     SmoothingList=Inner[Times,Table[Sign[sstar[[i]]],{i,Length[s]}],
                                   SmoothFuncs,List];
     SmoothingRules=
                 Inner[Rule,Table[Sign[sstar[[i]]],{i,Length[s]}],SmoothingList,List];
     control1=MapThread[((#1)/.#2)&,{control,SmoothingRules}];
          (* Apply Moderating *)
     G[x_,alp_]:=Norm[x]/(alp+Norm[x]);
     control2 = control1* G[z,alph];
     control2
     ]

SwitchingControl[alpha_?VectorQ,rho_?MatrixQ,z_List,s_,bounds_,Q_]:=Module[{sstar,
          control,decouplecontrol},
     sstar=Transpose[rho].Q.s;
     control=Map[(bounds[[#,1]]*UnitStep[sstar[[#]]]
             +bounds[[#,2]]*UnitStep[-sstar[[#]]])&,Range[1,Length[bounds]]];
     control=UnitStep2Sign[control];
     decouplecontrol=-MyInverse[rho].alpha+control;
    {decouplecontrol,sstar}
      ] 

SwitchingControl[alpha_?VectorQ,rho_?MatrixQ,z_List,s_,bounds_,Q_,eps_List]:=Module[{sstar,
          control,control1,control2,SmoothingList,SmoothingRules,SmoothFuncs,SmoothList,
          ModeratingList,ModeratingRules,ModeratingFuncs,ModerateList,F},
     {control,sstar}=SwitchingControl[alpha,rho,z,s,bounds,Q];
     F[x_,ep_]:=Tanh[x/eps];
                    (* Apply smoothing *)
     SmoothFuncs=MapThread[F[#1,#2]&,{sstar,eps}];
     SmoothingList=Inner[Times,Table[Sign[sstar[[i]]],{i,Length[s]}],
                                   SmoothFuncs,List];
     SmoothingRules=
                 Inner[Rule,Table[Sign[sstar[[i]]],{i,Length[s]}],SmoothingList,List];
     control1=MapThread[((#1)/.#2)&,{control,SmoothingRules}];
     control1
     ] 

SwitchingControl[alpha_?VectorQ,rho_?MatrixQ,z_List,s_,bounds_,Q_,eps_List,alph_]:=Module[{sstar,
          control,control1,control2,SmoothingList,SmoothingRules,SmoothFuncs,SmoothList,
          ModeratingList,ModeratingRules,ModeratingFuncs,ModerateList,F,G},
     {control,sstar}=SwitchingControl[alpha,rho,z,s,bounds,Q];
     F[x_,ep_]:=Tanh[x/eps];
                    (* Apply smoothing *)
     SmoothFuncs=MapThread[F[#1,#2]&,{sstar,eps}];
     SmoothingList=Inner[Times,Table[Sign[sstar[[i]]],{i,Length[s]}],
                                   SmoothFuncs,List];
     SmoothingRules=
                 Inner[Rule,Table[Sign[sstar[[i]]],{i,Length[s]}],SmoothingList,List];
     control1=MapThread[((#1)/.#2)&,{control,SmoothingRules}];
          (* Apply Moderating *)
     G[x_,alp_]:=Norm[x]/(alp+Norm[x]);
     control2 = control1* G[z,alph];
     control2
     ]
SetAttributes[SwitchingControl,ReadProtected];
SetAttributes[SwitchingControl,Protected];
SetAttributes[SwitchingControl,Locked];

(***************************** Utility ****************************)


ProdVp[V_,p_]:=V.p /; MatrixQ[V];                          
ProdVp[V_,p_]:=Module[{Finish,Start,Inds,VdimsCols,Vp},(
    VdimsCols = Flatten[Map[Dimensions, V]];
    LengthV = Length[VdimsCols];
    Finish = Map[Apply[Plus,Take[VdimsCols,#]]&,Range[1,LengthV]];
    Start = Finish-VdimsCols+1;
    Inds = Map[Range[Start[[#]],Finish[[#]]]&,Range[1,LengthV]];
    Vp = Flatten[Map[V[[#]].p[[Inds[[#]]]]&,Range[1,LengthV]]];
    Vp
   )];

Clear[NormalAbc];
NormalAbc[0]:={{{}},{},{}};
NormalAbc[n_Integer]:=Module[{Temp,A,b,c},
     If[n==1,Return[{{{0}},{1},{1}}],
      Temp=Join[IdentityMatrix[n-1],{Table[0,{i,n-1}]}];
      A=Transpose[Join[{Table[0,{i,n}]},Transpose[Temp]]];
      b=Join[Table[0,{i,n-1}],{1}];
      c=Join[{1},Table[0,{i,n-1}]]
     ];
      {A,b,c}
      ];

Clear[ExponentialRegulator];                
ExponentialRegulator[A_,b_?VectorQ,c_?VectorQ,decay_]:= 
    ExponentialRegulator[A,Transpose[{b}],{c},decay]
ExponentialRegulator[A_,B_?MatrixQ,C_?MatrixQ,decay_]:=
   Module[{nn=Length[A],
     mm=Dimensions[B][[2]],Q,R,KK,PP,eigs},
     Q=Transpose[C].C;
     R=IdentityMatrix[mm];
     {KK,PP,eigs}=LQR[A+decay*IdentityMatrix[nn],B,Q,R];
     KK
     ];
     
(************************************************************************)
(*                      MyInverse                                       *)
(************************************************************************)
(*  Finds the inverse symbolically, then substitutes the elements of the *)
(*    original matrix                                                   *)


Clear[MyInverse];

MyInverse[A_?MatrixQ]:=Module[{
mat,            (* matrix of symbolic terms of same size as A*)
a,              (* a[i,j] are elements of mat *)
Inv,            (* inverse[mat] *)
ElemsA,         (* List of elements of A *)
ZeroElemsA,     (* positions of the zero elements of A *)
NonZeroElemsA,  (* Complement of ZeroElemsA*)
ZeroRule,       (* Rule to substitute the zero elements first *)
NonZeroRule     (* Rule to substitute the rest of the elements *)
},
mat=Table[a[i,j], {i,Dimensions[A][[1]]},{j,Dimensions[A][[2]]}];
Inv=Inverse[mat];
ElemsA=Flatten[A];
ZeroElemsA=Flatten[Position[ElemsA,0]];
NonZeroElemsA=Complement[Range[Length[ElemsA]],ZeroElemsA];
ZeroRule=Thread[Flatten[mat][[ZeroElemsA]]->ElemsA[[ZeroElemsA]]];
NonZeroRule=Thread[Flatten[mat][[NonZeroElemsA]]->ElemsA[[NonZeroElemsA]]];
Inv/.ZeroRule/.NonZeroRule
]
SetAttributes[MyInverse,ReadProtected];
SetAttributes[MyInverse,Protected];
SetAttributes[MyInverse,Locked];

End[]

EndPackage[ ]

(* ********************************************************************** *)
(* ********************************************************************** *)
If[!spell1, On[General::spell1]];
If[!spell, On[General::spell]];

