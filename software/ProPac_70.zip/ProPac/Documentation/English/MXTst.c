#include <math.h>    
#include "trigfun.h"  
/* 
 *  
 *            Syntax  [sys, x0] = MXTst(t,x,u,flag,X0) 
*/ 
/* 
* The following #define is used to specify the name of this S-Function. 
*/ 
#define S_FUNCTION_NAME MXTst 
/* 
* need to include simstruc.h for the definition of the SimStruct and 
* its associated macro definitions. 
*/ 
#include "simstruc.h" 
  
/* 
 * mdlInitializeSizes - initialize the sizes array 
 * 
 * The sizes array is used by SIMULINK to determine the S-function block's 
 * characteristics (number of inputs, outputs, states, etc.). 
 */ 
static void mdlInitializeSizes(S) 
    SimStruct *S; 
{ 
    ssSetNumContStates(    S, 4);      /* number of continuous states */ 
    ssSetNumDiscStates(    S, 0);      /* number of discrete states */ 
    ssSetNumInputs(        S, 2 );      /* number of inputs */ 
    ssSetNumOutputs(       S, 2 );      /* number of outputs */ 
    ssSetDirectFeedThrough(S, 0);      /* direct feedthrough flag */ 
    ssSetNumSampleTimes(   S, 1);      /* number of sample times */ 
    ssSetNumInputArgs(     S, 1);      /* number of input arguments */ 
    ssSetNumRWork(         S, 0);      /* number of real work vector elements */ 
    ssSetNumIWork(         S, 0);      /* number of integer work vector elements */ 
    ssSetNumPWork(         S, 0);      /* number of pointer work vector elements */ 
     /* 
     * if there aren't the correct number of parameters, just return, simulink.c will 
     * flag the error 
     */ 
    if (ssGetNumArgs(S) != 1) 
       return; 
    if (mxGetM(ssGetArg(S,0)) != 4  || mxGetN(ssGetArg(S,0)) !=1)  { 
        mexErrMsgTxt( "X0 must have dimensions: 4 by 1"); 
        return; 
    } 
} 
/* 
 * mdlInitializeSampleTimes - initialize the sample times array 
 * 
 * This function is used to specify the sample time(s) for your S-function. 
 * If your S-function is continuous, you must specify a sample time of 0.0. 
 * Sample times must be registered in ascending order. 
 */ 
static void mdlInitializeSampleTimes(S) 
    SimStruct *S; 
{ 
    ssSetSampleTimeEvent(S, 0, 0.0); 
    ssSetOffsetTimeEvent(S, 0, 0.0); 
} 
/* 
 * mdlInitializeConditions - initialize the states 
 * 
 * In this function, you should initialize the continuous and discrete 
 * states for your S-function block.  The initial states are placed 
 * in the x0 variable.  You can also perform any other initialization 
 * activities that your S-function may require. 
 */ 
static void mdlInitializeConditions(x0, S) 
    double *x0; 
    SimStruct *S; 
{ 
    int i,imax; 
    double *X0pr; 
/* Set initial value for state vector */ 
    X0pr = mxGetPr(ssGetArg(S,0));  
    imax = mxGetM(ssGetArg(S,0)); 
    for(i=0;i<imax;i++){ 
        x0[i] = X0pr[i]; 
    } 
} 
/* 
 * mdlDerivatives - compute the derivatives 
 * 
 * In this function, you compute the S-function block's derivatives. 
 * The derivatives are placed in the dx variable. 
 */ 
static void mdlDerivatives(dx, x, u, S, tid) 
    double *dx, *x, *u; 
    SimStruct *S; 
    int tid; 
{  
    int n; 
    double s1, s2, s3, s4, s5, s6, s7, s8, s9, s10; 
    double t1, t2, t3; 
    double *RWork = ssGetRWork(S); 
    int i,j; 
    char s='L'; 
    int nrhs, LDA, info; 
    n = 4; 
    t1 =    pow(List(x1,x2,x3,x4)(3.0000000),2.); 
    t2 =    pow(List(x1,x2,x3,x4)(0),2.); 
    t3 =    1/(5.000000+4.000000*t2-4.000000*List(x1,x2,x3,x4)(0)); 
  dx[0] =     List(x1,x2,x3,x4)(1.0000000); 
  dx[1] =     List(u1,u2)(0)+t1*(-0.5000000+List(x1,x2,x3,x4)(0)); 
  dx[2] =     List(x1,x2,x3,x4)(3.0000000); 
  dx[3] =     t3*(4.000000*List(u1,u2)(1.0000000)+(4.000000-8.000000*List(x1,x2,x3,x4)(0))*List(x1,x2,x3,x4)(1.0000000)*List(x1,x2,x3,x4)(3.0000000)); 
} 
/* 
 * mdlOutputs - compute the outputs 
 * 
 * In this function, you compute the outputs of your S-function 
 * block.  The outputs are placed in the y variable. 
 */ 
static void mdlOutputs(y, x, u, S, tid) 
    double *y, *x, *u; 
    SimStruct *S; 
    int tid; 
{ 
    double s1, s2, s3, s4, s5, s6, s7, s8, s9, s10; 
  
    y[0] =     List(x1,x2,x3,x4)(0); 
    y[1] =     List(x1,x2,x3,x4)(2.0000000); 
} 
/* 
 * mdlUpdate - perform action at major integration time step 
 * 
 * This function is called once for every major integration time step. 
 * Discrete states are typically updated here, but this function is useful 
 * for performing any tasks that should only take place once per integration 
 * step. 
 */ 
static void mdlUpdate(x, u, S, tid) 
    double *x, *u; 
    SimStruct *S; 
    int tid; 
{ 
} 
/* 
 * mdlTerminate - called when the simulation is terminated. 
 * 
 * In this function, you should perform any actions that are necessary 
 * at the termination of a simulation.  For example, if memory was allocated 
 * in mdlInitializeConditions, this is the place to free it. 
 */ 
static void mdlTerminate(S) 
    SimStruct *S; 
{ 
} 
#ifdef MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */ 
#include "simulink.c"      /* MEX-file interface mechanism */ 
#else 
#include "cg_sfun.h"       /* Code generation registration function */ 
#endif 
