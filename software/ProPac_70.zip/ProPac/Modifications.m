(* ::Package:: *)

July 20, 1998: corrected sign error in SlidingSurface
Aug 17, 1998: IOLinearize returns NULL if relative degree is infinite 
   (Previously only tested singularity of decoupling matrix. But in some
   cases decoupling matrix cannot be computed correctly when relative degree is infinite)
Aug 18, 1998: modified sliding surface to exit gracefully when IOLinearize returns NULL.
Sept 24, 1998: corrected Help for SmoothingFunctions
Oct 6, 1998: corrected the function Poles to give correct multiplicities. Now computes 
	LCD of all minors of all orders. New examples in Help.
Oct 6,1998: Added a new function Zeros[G,s] that computes transmission zeros of a given transfer
	matrix.
Oct 9, 1998: Added a new function MatlabFormPolynomials & created a new sub-package
	MatlabInterface that includes MatlabForm and MatlabFormPolynomials. The new function
   writes the coefficients of polynomial matrices in Matlab readable form.
Oct 16, 1998: Added new functions MinimalRealization[G,s], MinimalRealization[A,B,C,D] and 
	KalmanDecomposition[A,B,C,D,opts]. The option is IrreducibleRealizaton->True returns only
   the controllable & observable part.
Oct 23, 1998: Modified help for SISONormalFormTrans.
Oct 26, 1998: Modified help for Joints.
Oct 26, 1998: Modified first output line of MatlabFormPolynomials to be a (Matlab) string.
Dec 26, 1998: Corrected Poles to work properly for scalar transfer functions.
Dec 26, 1998: Modified Nyquist to accept options: PlotRange, SenitivityPeak, Bandwidth and
	Margins.
Dec 26, 1998: Modified ColorNyquist to accept the same options as Nyquist. Also, to
	accommodate poles on the imaginary axis.
Jan 28, 1999: Modified ColorNyquist to have polar coordinates. Modified RootLocus to have 
	polar coordinates. Modified Bode coordinate colors.
Jan 28, 1999: ExponentialObserver. Corrected sign. Corrected eigenvalue output. Corrected 
	observability test (test functon name has been changed from Observable to 
   ObservablePair).
Feb 25, 1999: Added the option LocalControllability to the Controllability test.
March 14, 1999: Corrected SlidingSurface to handle case where sliding mode is of 
	dimension zero. This can nontrivially arise when using backstepping.
March 28, 1999: Added MakeODEs for a first order system q_dot=F (q,t).
March 28, 1999: Added capability for exact composition of flows (FlowComposition).
March 30, 1999: Added the functions TriangularDecomposition, SmallestInvariantDistribution,
   LargestInvariantDistribution.
August 22, 1999: Added the functions LyapunovEquation, PhasePortrait, MakeLagrangeEquations,
	and Sig.
Sept. 27, Added the functions LocalDecomposition (a Kalman decomposition for nonlinear 
	systems)
Sept. 29, Added the functions Obsrvability, ObervabilityCodistribution.
Sept. 29, Added a Controllability/Observability section to on-line help.
Oct 18, 1999: Corrected integration time in PhasePortrait.
Oct 18, 1999: Added DamperPotential.
Oct 24, 1999: Modified Needs[] in packages to accommodate changes in standard 
      package loading in Mathematica V4 .0.
Nov 28, 1999: Corrected Nyquist sensitivy function circle radius. Modified help.
Dec 5, 1999: Added DiracDelta simplification functions absent from V4 .0.
Dec 23, 1999: Added function index to help browser.
Jan 4, 2000: Modifications to account for CForm functional changes in V4 .0.
Jan 11, 2000: Replace NullSpace with SpecialNullSpace in DifferentialConstraints.
Jan 12, 2000: Added option to CreateModelMEX to control line length.
May 17, 2000: Added functions SeriesExpansion, Truncate, MatlabForm, MatlabFormPolynomials 
to Browser Index.
May 18, 2000: Modified ExpMap to give some speed improvement -- avoid recomputing Lie
derivatives.
Oct 2, 2000: Modified MyInverse so that zero positions are identified at level 1 of the 
matrix. This allows the matrix to contain expressions that may include nonzero elements
having zero parts at deeper levels.
Oct 8, 2000: Added to Span to allow computing the span of a set of vector fields at a 
specifed point (possibly a singular point) in addition to generic (regular) points.
Oct 9, 2000: Added to Rank, ControlDistribution, ObservabilityDistribution, 
LargestInvariantDistribution, SmallestInvariantDistribtion, FeedbackLinearizable to 
allow evaluation at a specified point in addition to generic evaluations.
Nov 8, 2000: Modified RootLocus to use Together before taking Denominator to insure
polynomial is identified before invoking NSolve. This resolves an issue with V4 .0.
Nov 8, 2000: Added PlotRange option to RootLocus.
Dec 3, 2000: Fixed RootLocus to correctly handle cases with no zeros.
Jan 17, 2001: Added Option MinimumBreakVariables->10 to CreateModelMex.
Feb 16, 2001: Added differential form package.
Feb 19, 2001: FormQ modified to exclude Head===List.
April 26, 2001: ReplaceVariablesStr and ReplaceVariablesStr1 modified so that pointer replacements
occur as expressions, not strings. Bracket corrections () to [] are then made for pointers as strings.
April 26, 2001: In SpringPotential, SpringForce, DamperPotential, DamperForce, Abs was removed from
Sqrt[Abs[x]^2].
June 8, 2001: Modified package "Needs" control to accommodate V4 .1.
Dec 18, 2001: Added definitions Rank[{}]=0, SpecialNullSpace[SpecialNullSpace[{}]]={}.
Jan 14, 2002: Simplified LocalInverseTransformation to achieve speed improvement.
Feb 20, 2002: Added ObserverTools.
April 16, 2002: Added additional simplification rules to Sqrt. Modified SpringPotential and SpringForce
to use Sqrt instead of ^(1/2).
Sept 17, 2002: Modifed NodeVelocity and ChainInertia. Joint translation for rigid bodies was not
included in Phi calculation.
April 8, 2003: Declared K to be a local variable in modules for LQR, LQE.
May 2, 2003: Modified Sign simplification to avoid error messages upon reloading ProPac. Evidently, V 4.2
compatibility issue.
July 6, 2003: Modified SISONormalFormTrans to pick out all arguments after obtaining solution from DSolve.
July 6, 2003: Removed \infty from ControlL string. Evidently, V 5.0 identifies this as an error.
July 23, 2003: Modified MEX functions to avoid conflicts with Global`u, Global`x.
Dec 28, 2003: Various modifications to ObserverTools.
June 3, 2004: Corrections to SlidingSurface.
June 28, 2005: Added carriage return to MatlabForm.
Jan 15, 2007: Modified derivative of Abs so D[Abs[x],x]=Sign[x]
Jan 15, 2007: Modified Sqrt so that Sqrt[x^2]=Sign[x] x
March 13, 2007: Modified RelativeOrder and VectorRelativeOrder. Multivariable case gave inconsistent results.
Nov 5, 2007: Replaced SingularValues with SingularValueDecomposition
Nov 16, 2007: Removed Trig->True from SpecialNullSpace
March 6, 2009: Modified DiracdeltaExtensions to avoid error messages in Mathematica 7.
March 8, 2009: Modified NormalizeParam to improve parameter scaling for surface generation around bifurcation points.
March 9, 2009: Added Ver 7 to ControlL
April 27, 2012: Added Ver 8 to ControlL
April 28, 2012: Removed MatrixManipulation package. Replaced AddColumns, AddRows functionality in ControllabilityMatrix, 
ObservabilityMatrix. Added SquareMatrixQ function.
