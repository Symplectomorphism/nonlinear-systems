(* ::Package:: *)

(*                ObserverTools


           Techno-Sciences, Inc.
           10001 Derekwood Lane, Suite 204
           Lanham, MD 20706
           (301) 577-6000
           
           
Copyright \[Copyright] 1997, 1998, 2000, 2001, 2002 Techno-Sciences Incorporated
All Rights Reserved          
           
*)
spell1 = (Head[General::spell1] === $Off);
spell = (Head[General::spell] === $Off);
Off[General::spell1];
Off[General::spell]; 



BeginPackage["ProPac`ObserverTools`",{"ProPac`GeoTools`","ProPac`DifferentialForms`"}]

(* ********************************************************************** *)
(* ********************************************************************** *)

(* Function Usage Statements *)

ObserverTools::usage = "
This package prvides the functions\n
\n
ObservabilityIndices, LinearizeToOutputInjection,\n
ObservableForm, PDESolve\n
"

ObservabilityIndices::usage = "
ObservabilityIndices[f,h,x,u] returns a list of the\n
observability indices of the system\n
\n
   x_dot = f(x,u)\n
       y = h(x)\n
"

LinearizeToOutputInjection::usage = "
LinearizeToOutputInjection[f,h,x,u] returns a transformation \n
x -> z(x) that converts the system\n
\n
   x_dot = f(x,u)\n
       y = h(x)\n
into the form\n
   z_dot = A(u)x+\[Phi](y) \n
"

ObservableForm::usage = "
ObservableForm[f, h, x, u] returns a list {Trans, Ind} \n
where Trans is a transformation x -> z(x) that converts the system\n
\n
   x_dot = f(x,u)\n
       y = h(x)\n
into observable form. Ind is a list of observability indices.\n
"

PDESolve::usage="
PDESolve[f_List,x_List] solves a set of n integrable, first order\n 
partial differential equations of the form:\n
	\[PartialD]u/\[PartialD]\!\(TraditionalForm\`x\_1\)=\!\(TraditionalForm\`f\_\
1\)(\!\(TraditionalForm\`x\_1\),...,\!\(TraditionalForm\`x\_n\)),...,\
\[PartialD]u/\[PartialD]\!\(TraditionalForm\`x\_n\)=\!\(TraditionalForm\`f\_n\
\)(\!\(TraditionalForm\`x\_1\),...,\!\(TraditionalForm\`x\_n\))
   "

ControlSequences::usage = " "

(* ****** Options ****** *)


(* ****************************************************** *)

(*  Functions *)

Begin["`private`"]

(* ****************************************************** *)
(*
Control Sequences
*)
Clear[ControlSequences]
ControlSequences[f_?VectorQ,h_?VectorQ,u_?VectorQ,x_?VectorQ] := \
Module[{Diffs,Codist={},Codist1,k=0,Res,LL=h,rule1,uk,nk,ContrSeq={},\
Sequencek0,Sequencek={},rulek,TestList,DropList,NullControls,ZeroControls,\
NonZeroControls,MoreNonZeroControls,ShortList,UnitControls,MyLast,TestCodist,\
LastCodist,TempSequence0,TempSequence1},

Diffs = Map[ToExpression["d["<>ToString[#]<>"]"]&,x];
MyLast[A_]:=If[A==={},{},Last[A]];
(* Set up the codistribution E0 *)
Codist=SpanD[Jacob[h,x]].Diffs;
Res={Length[Codist]};
(* Main Loop proceeds until dim Codist= dim x or k= dim x. *)
While[Length[FormBasis[Codist,x]]<Length[x]&&k<Length[x],
  k=k+1;
  (* define uk, kth contol vector *)
  uk=Map[ToExpression[ToString[#]<>ToString[k]]&,u];
  (* proceed to set up the codistribution Ek *)
  rule1=Inner[Rule,u,uk,List];
  LL=LieDerivative[f/.rule1,LL,x];
  LastCodist=Codist;
  Codist=FormSimplify[Union[Codist,Jacob[LL,x].Diffs]];
  (* recall, Ek= (dL_f_uk....L_f_u1) U dh *) 
  (* define a basis for Codist, with generic uk, The codimension of
  E_(k-1) in E_k is nk *)
  Codist1=FormBasis[Codist,x];nk=Length[Codist1]-Last[Res];
  If[nk<1,Print["codimension = 0 at k= "<>ToString[k]<>"! Unresolved \
issue."];Return[{}]];
  (* get the positions in uk where a zero value does not reduce the rank of \
Codist *) 
  (*  first set up a list of dimensions of Codist with individual elements of \
uk->0 *)
  TestList=Map[Length[FormBasis[Codist/.#->0,x]]&,uk];
  DropList=Reverse[Position[TestList,Length[Codist1]]]; (* this is a list of \
positions in uk that may be set to zero. *)
  (* the list of elements that must be nonzero are: *)
  NonZeroControls=uk;
  NonZeroControls=MyLast[Map[(NonZeroControls=Drop[NonZeroControls,#])&,\
DropList]];
  (* and the controls that can (individually) be zero *)
  ZeroControls=Complement[uk,NonZeroControls];
  (* Which elements of uk actually appear in Codist1? *)
  ShortList=Apply[Union,Map[Cases[Codist,#,Infinity]&,uk]];
  (* NullControls=Intersection[ShortList,ZeroControls]; *)
  NullControls=ZeroControls;
  Sequencek0=uk;
  While[NullControls=!={},
    If[RankCodistribution[Codist1/.NullControls[[1]]->0,x]===Length[Codist1],
      Sequencek0=Sequencek0/.NullControls[[1]]->0;
      Codist1=Codist1/.NullControls[[1]]->0];
    NullControls=Drop[NullControls,1]
  ];
  (* Are there ZeroControls left? *)
  MoreNonZeroControls=Union[Flatten[Map[Cases[Codist1,#,Infinity]&,uk]]];
  UnitControls=Intersection[ShortList,NonZeroControls];
  (* UnitControls=Intersection[Complement[uk,ShortList],NonZeroControls]; *)
  (* UnitControls=Union[NonZeroControls,Complement[uk,ShortList]]; *)
  While[UnitControls=!={},
    If[RankCodistribution[Codist1/.UnitControls[[1]]->1,x]===Length[Codist1],
      Sequencek0=Sequencek0/.UnitControls[[1]]->1;
      Codist1=Codist1/.UnitControls[[1]]->1];
    UnitControls=Drop[UnitControls,1]
  ];
  UnassignedControls=Map[Cases[Codist1,#,Infinity]&,uk];
  If[Flatten[UnassignedControls]=!={},
    Print["Warning! The following controls have not been assigned values:"];
    Print[UnassignedControls]
  ];
  (* Now construct the independent sequences *)
  (* Begin by generating a list of controls with each 0 replaced by 1" *)
  TempSequence0={Sequencek0};TempSequence1={Sequencek0};Sequencek1={\
Sequencek0};
  While[(Position[Flatten[TempSequence1],0]=!={}),
  While[TempSequence0=!={},               
    TempSequence1=Union[Map[ReplacePart[TempSequence0[[1]],1,#]&,Flatten[\
Position[TempSequence0[[1]],0]]]];
    Sequencek1=Union[Sequencek1,TempSequence1];
    TempSequence0=Drop[TempSequence0,1]
   ];
   TempSequence0=TempSequence1
  ];
  (* Pick out nk of these controls that do not reduce the rank of E_k *)
  Sequencek={};rulek={};Codist1=FormBasis[Codist,x];
  (* in the following use 1 instead of nk *)
  TestCodist=LastCodist;
  While[Sequencek1=!={},
       If[RankCodistribution[Codist/.Inner[Rule,uk,Sequencek1[[1]],List],x]
                   >RankCodistribution[TestCodist,x],
        TestCodist=Join[TestCodist,Codist/.Inner[Rule,uk,Sequencek1[[1]],List]\
];
        Sequencek=Join[Sequencek,{Sequencek1[[1]]}]
        ];
      Sequencek1=Drop[Sequencek1,{1}]
  ];
  Codist=TestCodist;
  ContrSeq=If[ContrSeq==={},
             {Transpose[{Sequencek}]},
             (* \
Join[ContrSeq,{Flatten[Outer[List,Flatten[MyLast[ContrSeq],1],Sequencek,1],1]}\
] *)
             Join[ContrSeq,{Flatten[Outer[Join,MyLast[ContrSeq],{Sequencek},1]\
,1]}]
           ];
  Codist=FormBasis[Codist,x];
  Res=Join[Res,{Length[Codist]}]
];(* end main loop *)
If[Length[Codist]<Length[x],Print["System is not observable."];Return[{}]];
{Map[(Res[[#+1]]-Res[[#]])&,Range[Length[Res]-1]],ContrSeq}
]

(*
Observability Indices, Compute Y, X
*)

Clear[ObservabilityIndices]
ObservabilityIndices[W_?MatrixQ, h_?VectorQ] := 
    Module[{q = Length[h], p, STemp, S, SS, T, kk},
      p = Length[W];
      S = Table["S" <> ToString[i], {i, q}];
      SS = W[[Range[q]]];
      If[Rank[SS] =!= q, Print["Outputs are not independent!"]; Return[{}]];
      For[k = 1, k <= q, k++, S[[k]] = {W[[k]]}];
      For[j = q + 1, j <= p, j++,
        STemp = Join[SS, {W[[j]]}];
        If[Rank[STemp] =!= Rank[SS], SS = STemp; kk = Mod[j, q]; 
          If[kk === 0, kk = q]; S[[kk]] = Join[S[[kk]], {W[[ j]]}]]
        ];
      T = {};
      Map[(T = Join[T, S[[#]]]) &, Range[q]];
      {T, Map[Length[#] &, S]}
      ];
ObservabilityIndices[f_?VectorQ, h_?VectorQ, x_?VectorQ, u_?VectorQ,Seq_List] := 
  Module[{p = Length[Seq], Seqk, k = 1, LL, Eqn, M, Ind, A, B, nh = Length[h],
        pk, kk = 0}, 
    M = Jacob[h, x];
    While[k <= p, Seqk = Seq[[k]];
      pk = Length[Seqk];
      LL = {};
      While[Seqk =!= {}, Lkh = h;
        Map[(Lkh = LieDerivative[f /. Inner[Rule, u, #, List], Lkh, x]) &, 
          Seqk[[1]]];
        LL = Join[LL, Lkh];
        Seqk = Drop[Seqk, 1]];
      M = Join[M, Jacob[LL, x]];
      k++];(* Print[FullSimplify[M] // MatrixForm]; *)
    {A, Ind} = ObservabilityIndices[FullSimplify[M], h];
    Ind];
ObservabilityIndices[f_?VectorQ, h_?VectorQ, x_?VectorQ, u_?VectorQ] := 
  Module[{Ind, Seq},
    {Ind, Seq} = ControlSequences[f, h, u, x];
    ObservabilityIndices[f, h, x, u, Seq]
    ];

Clear[YEqns]
YEqns[f_?VectorQ,h_?VectorQ,x_?VectorQ,u_?VectorQ,Seq_List]:=Module[{p=Length[\
Seq],Seqk,k=1,LL,Eqn,M,Ind,A,B,nh=Length[h],pk,kk=0},
M=Jacob[h,x];
(* Eqn=Inner[Equal,LieDerivative[Y,h,x],Table[0,{Length[h]}],List];
LL=Map[ToExpression["LL"<>ToString[#]]&,Range[p]];Print[LL]; *)
While[k<=p,
Seqk=Seq[[k]];
pk=Length[Seqk];
LL={};
  While[Seqk=!={},
    Lkh=h;
    Map[(Lkh=LieDerivative[f/.Inner[Rule,u,#,List],Lkh,x])&,Seqk[[1]]];
    LL=Join[LL,Lkh];
    Seqk=Drop[Seqk,1]
  ];
M=Join[M,Jacob[LL,x]];
k++
];
{A,Ind}=ObservabilityIndices[M,h];
B=Table[0,{i,1,Length[x]},{j,1,nh}];
Map[(kk=kk+Ind[[#]];B=ReplacePart[B,1,{kk,#}])&,Range[nh]];
Transpose[LinearSolve[A,B]]
]

(*
YEqns[f_?VectorQ,h_?VectorQ,x_?VectorQ,u_?VectorQ,Seq_List]:=Module[{p=Length[\
Seq],Seqk,k=1,Y,LL,Eqn},
Y=Map[ToExpression["Y"<>ToString[#]]&,Range[Length[x]]];
Eqn=Inner[Equal,LieDerivative[Y,h,x],Table[0,{Length[h]}],List];
(* LL=Map[ToExpression["LL"<>ToString[#]]&,Range[p]];Print[LL]; *)
While[k<=p,
Seqk={Seq[[k]]};
LL={};
  While[Seqk=!={},
    Lkh=h;
    Map[(Lkh=LieDerivative[f/.Inner[Rule,u,#,List],Lkh,x])&,Seqk[[1]]];
    LL=Join[LL,Lkh];
    Seqk=Drop[Seqk,1]
  ];
If[k<p,
  Eqn=Join[Eqn,Inner[Equal,LieDerivative[Y,LL,x],Table[0,{Length[LL]}],List]],\

  Eqn=Join[Eqn,Inner[Equal,LieDerivative[Y,LL,x],Table[1,{Length[LL]}],List]]
];
k++
];
Flatten[Y/.Solve[Eqn,Y]]
]/;Length[h]===1;
*)

Clear[ScalarQ]
ScalarQ[x_]:= !(Head[x]===List||FormQ[x]);

Clear[ConstructX]
ConstructX[f_?VectorQ,h_?VectorQ,x_?VectorQ,u_?VectorQ,Y_?VectorQ,Ind_List]:= \
ConstructX[f,h,x,u,Y,Ind[[1]]-1]/;Length[h]===1;
ConstructX[f_?VectorQ,h_?VectorQ,x_?VectorQ,u_?VectorQ,Y_?VectorQ,p_Integer]:=
Module[{Z,U,UU,UUU,UU1,UU1kk,LZh,LZh0,X},
U=Map["u"<>ToString[#]&,Range[p]];
For[k=1;UU={},k<=p,
  UU=Join[UU,{Map[ToExpression[U[[k]]<>ToString[#]]&,Range[Length[u]]]}];
  k++
  ];
Z=Y;
Map[(Z=LieBracket[f/.Inner[Rule,u,#,List],Z,x])&,UU];
Z=Simplify[Z];
LZh=LieDerivative[Z,h,x];
UUU=Flatten[UU];UU0=0*UUU;UU1kk=UU0;
LZh0=LZh/.Inner[Rule,UUU,UU0,List];
For[k=1,LZh0==={0}&&k<=Length[UU0],
  UU0=ReplacePart[UU0,1,k];
  UU1=Permutations[UU0];
  For[kk=1,LZh0==={0}&&kk<=Length[UU1],
     UU1kk=UU1[[kk]];
     LZh0=LZh/.Inner[Rule,UUU,UU1kk,List];
     kk++
     ];
  k++
  ];
If[LZh0[[1]]=!=0,X=(Z/.Inner[Rule,UUU,UU1kk,List])/LZh0[[1]],Return[{}]];
X/.Inner[Rule,UUU,UU1kk,List]
]/;Length[h]===1;

ConstructX[f_?VectorQ, h_?VectorQ, x_?VectorQ, u_?VectorQ, Y_?MatrixQ, 
    Ind_List] := 
  Module[{p, nh = Length[h], Z, U, UU, UUU, UU1, UU1kk, LZh, LZh0, X, ZZ, 
      ZTemp = {}},
    p = Max[Ind] - 1;
    U = Map["u" <> ToString[#] &, Range[p]];
    For[k = 1; UU = {}, k <= p, 
      UU = Join[
          UU, {Map[ToExpression[U[[k]] <> ToString[#]] &, 
              Range[Length[u]]]}];
      k++];
    Z = Y;
    For[k = 1, k <= nh,
      ZZ = Z[[k]];
      For[kk = 1, kk < Ind[[k]],
        ZZ = LieBracket[f /. Inner[Rule, u, UU[[kk]], List], ZZ, x];
        kk++
        ];
      ZTemp = Join[ZTemp, {Simplify[ZZ]}];
      k++
      ];
    Z = ZTemp;
    LZh = Map[LieDerivative[#, h, x] &, Z];
    UUU = Flatten[UU]; UU0 = 0*UUU; UU1kk = UU0;
    LZh0 = LZh /. Inner[Rule, UUU, UU0, List];
    For[k = 1, Rank[LZh0] < nh && k <= Length[UU0], 
      UU0 = ReplacePart[UU0, 1, k];
      UU1 = Permutations[UU0];
      For[kk = 1, Rank[LZh0] < nh && kk <= Length[UU1], UU1kk = UU1[[kk]];
        LZh0 = LZh /. Inner[Rule, UUU, UU1kk, List];
        kk++];
      k++];
    If[Rank[LZh0] == nh, X = LinearSolve[LZh0, Z], Return[{}]];
    X /. Inner[Rule, UUU, UU1kk, List]]
    
(*
Omega Construction
*)
Clear[LieDerivative1]
LieDerivative1[f_?VectorQ, w_?FormQ, x_?VectorQ] := 
    FormSimplify[
        Sum[Jacob[Coefficient[w, d[x[[i]]]], x].f d[x[[i]]] + 
            Sum[Coefficient[w, d[x[[j]]]] D[f[[j]], x[[i]]], {j, 
                  Length[x]}] d[x[[i]]], {i, Length[x]}]] /; 
      FormDegree[w] === 1;
LieDerivative1[f_?VectorQ, 0, x_?VectorQ] := 0;
Clear[MultiContraction]
MultiContraction[omega_?FormQ, XX_?VectorQ, xx_?VectorQ] := 
    Contraction[omega, XX, xx];
MultiContraction[omega_?FormQ, XX_?MatrixQ, xx_?VectorQ] := 
    Module[{Q = omega}, 
      Map[(Q = Contraction[Q, XX[[-#]], xx]) &, Range[Length[XX]]];
      Q];
   
Clear[MyFreeQ]
MyFreeQ[a_List, x_List] := Module[{},
      For[j = 1, j <= Length[a], j++, 
        For[i = 1, i <= Length[x], i++, 
          If[! FreeQ[a[[j]], x[[i]]], Return[False]]]];
      True];
   
Clear[FormCoefficient]  
FormCoefficient[W_, WW_?FormQ] :=
    If[Head[WW] === Plus, 
      Apply[Intersection, Map[Coefficient[W, {#}] &, Level[WW, 1]]], 
      Coefficient[W, WW]];
   
Clear[InSpanOverReals]
InSpanOverReals[F_?MatrixQ, v_?VectorQ, x_?VectorQ] := 
    Module[{K, k, A, Keep, FreeTest},
      A = Join[F, {v}];
      K = Table[k[i], {i, Length[F] + 1}];
      FreeTest[A_, z_] := Apply[And, Map[FreeQ[A, #] &, z]];
      eqns = 
        Inner [Equal, (Flatten[K[[Range[Length[F] + 1]]].A]) /. 
            k[Length[F] + 1] -> 1, 0*Flatten[A[[1]]], And];
      (* Print["eqns="];
        Print[eqns]; *)
      sols = 
        LogicalExpand[
          Reduce[eqns && (Apply[Alternatives, 
                    K[[Range[Length[F]]]]]) \[Element] Reals, 
            Join[K[[Range[Length[F]]]], x], Reals]];
      (* Print[sols]; *)
      If[sols === False, Keep = True,
        If[Head[sols] === And, 
          If[(Apply[And, Map[FreeQ[sols, #] &, x]]), Keep = False, 
            Keep = False],
          
          Temp = Map[FreeTest[#, x] &, 
              Map[sols[[#]] &, Range[Length[sols]]]];
          DropTest = Apply[Or, Temp];
          If[DropTest, Keep = False, Keep = True]
          ]
        ];
      ! Keep
      ];
InSpanOverReals[W_, v_?FormQ, x_?VectorQ] := 
    Module[{m, coords = Sort[x], n = Length[x], Diffs, Indices, WedgeList, F, 
          V},
        m = FormDegree[W[[1]]];
        Diffs = Map[ToExpression["d[" <> ToString[#] <> "]"] &, coords];
        Indices = Permutations[Join[Table[1, {m}], Table[0, {n - m}]]];
        WedgeList = 
          If[m === 1, Diffs, 
            Map[Apply[Wedge, Diffs[[Flatten[Position[#, 1]]]]] &, Indices]];
        F = Transpose[Map[Coefficient[W, #] &, WedgeList]];
        V = Map[Coefficient[v, #] &, WedgeList];
        InSpanOverReals[F, V, x]] /; 
      W != {} && FormDegree[W[[1]]] === FormDegree[v] && 
        Inner[SameQ, Map[FormDegree[#] &, W], 
          Table[FormDegree[W[[1]]], {Length[W]}], And];
InSpanOverReals[{}, v_?FormQ, x_?VectorQ] := False;

(* ***************************************************** *)
(* FormCoefficients expands a given form in terms of a given basis set *)

Clear[FormCoefficients];
FormCoefficients[W_, v_?FormQ] := Map[Coefficient[v, #] &, W]

(* ***************************************************** *)
(* FormProjection projects a form onto a specified subspace *)

Clear[FormProjection]
FormProjection[U_, V_, x_?VectorQ] := 
  Module[{B, UCoeff, UTest, VCoeff, E, OrthProj, VPerp, VKeep = {}},
      B = FormBasis[Join[U, V], x];
      UCoeff = Map[FormCoefficients[B, U[[#]]] &, Range[Length[U]]];
      UTest = UCoeff;
      VCoeff = Map[FormCoefficients[B, V[[#]]] &, Range[Length[V]]];
      E = Transpose[UCoeff];
      OrthProj = IdentityMatrix[Length[B]] - E.LeftInverse[E];
      VPerp = Transpose[OrthProj.Transpose[VCoeff]];
      Map[
        If[Rank[UTest] === Rank[Join[UTest, {VPerp[[#]]}]], VKeep = VKeep, 
            VKeep = Join[VKeep, {VPerp[[#]]}]; 
            UTest = Join[UTest, VPerp[[#]]]] &, Range[Length[VPerp]]];
      VKeep.B
      ] /; U =!= {}
FormProjection[{}, V_, x_?VectorQ] := V;

(* ***************************************************** *)
(* FormProjectionOverReals projects a form onto a given subspace only if the \
projection operator is independent of the coordinates *)

Clear[FormProjectionOverReals]
FormProjectionOverReals[U_, V_, x_?VectorQ] := 
  Module[{B, UCoeff, UTest, VCoeff, E, OrthProj, VPerp, VKeep = {}},
      B = FormBasis[Join[U, V], x];
      UCoeff = Map[FormCoefficients[B, U[[#]]] &, Range[Length[U]]];
      UTest = UCoeff;
      VCoeff = Map[FormCoefficients[B, V[[#]]] &, Range[Length[V]]];
      E = Transpose[UCoeff];
      OrthProj = IdentityMatrix[Length[B]] - E.LeftInverse[E];
      If[(Apply[And, Map[FreeQ[OrthProj, #] &, x]]), 
        VPerp = Transpose[OrthProj.Transpose[VCoeff]], VPerp = VCoeff];
      Map[
        If[Rank[UTest] === Rank[Join[UTest, {VPerp[[#]]}]], VKeep = VKeep, 
            VKeep = Join[VKeep, {VPerp[[#]]}]; 
            UTest = Join[UTest, VPerp[[#]]]] &, Range[Length[VPerp]]];
      VKeep.B
      ] /; U =!= {}
FormProjectionOverReals[{}, V_, x_?VectorQ] := V;

(* ***************************************************** *)
(* SimplifyFormBasisOverReas tries to produce an orthogonal basis using \
linear combinations with real coefficients *)
Clear [SimplifyFormBasisOverReals]
SimplifyFormBasisOverReals[U_, x_?VectorQ] := Module[{Basis = {}},
        Map[(Basis = 
                Join[Basis, FormProjectionOverReals[Basis, {U[[#]]}, x]]) &, 
          Range[Length[U]]];
        Basis
        ] /; U =!= {};
SimplifyFormBasisOverReals[{}, x_?VectorQ] := {};

(* ***************************************************** *)
(* OmegaForms *)
Clear[OmegaForms]
OmegaForms[f_?VectorQ,h_?VectorQ,u_?VectorQ,x_?VectorQ,X_?VectorQ]:=
  OmegaForms[f,h,u,x,{X}];
OmegaForms[f_?VectorQ,h_?VectorQ,u_?VectorQ,x_?VectorQ,X_?MatrixQ]:=
Module[{Diffs,q=Length[h],n=Length[x],dh,DH,W,Omega,Omega0,Omega00,Omega1,\
Omegak,
        OmegaLast,u0,ushort,U1,U1kk,
        MultiContraction,rulek={}},
(* create d[x1]....d[xn] *)

Diffs = Map[ToExpression["d["<>ToString[#]<>"]"]&,x];
MultiContraction[omega_?FormQ,XX_?MatrixQ,xx_?VectorQ]:=Module[{Q=omega},
    Map[(Q=Contraction[Q,XX[[-#]],xx])&,Range[Length[XX]]];
    Q
    ];
(* Create DH=dh1\[And]dh2..\[And]dhq *)
dh=Jacob[h,x].Diffs;
DH=dh[[1]];Map[(DH=Wedge[DH,dh[[#]]])&,Range[2,q]];
(* *********************************** *)
(* Initialize main loop, define Omega0 *)
Omega1=FormSimplify[Map[Wedge[LieDerivative1[f,#,x],DH]&,dh]];
(* ushort=Apply[Union,Map[Cases[Omega1,#,Infinity]&,u]]; *)
ushort=u;
u0=0*ushort;Omega0=Omega1/.Inner[Rule,ushort,0*ushort,List];
Omega00=Omega1/.Inner[Rule,ushort,u0,List];
Omega00=Delete[Omega00,Position[Omega00,0]];
Omega0={};
For[k=1,(k<=n-q)&&k<=Length[Omega00],
If[InSpanOverReals[Omega0,Omega00[[k]],x],Omega0=Omega0,Omega0=Join[Omega0,
       {Omega00[[k]]}]];
k++
];
If[Length[Omega0]===n-q,Return[Omega0]];
For[k=1,k<=Length[ushort],
  u0=ReplacePart[u0,1,k];
  U1=Permutations[u0];
  For[kk=1,kk<=Length[U1],
     U1kk=U1[[kk]];
     If[ushort=!={},rulek=Inner[Rule,ushort,U1kk,List],{}];
     Map[If[InSpanOverReals[Omega0,Omega1[[#]]/.rulek,x],Omega0=Omega0,Omega0=\
Join[Omega0,
     {Omega1[[#]]/.rulek}]]&,Range[Length[Omega1]]];
     kk++
     ];
  k++
  ];
Omega=FormSimplify[Omega0];OmegaLast=Omega;Omegak=Omega;
(* *************************************** *)
(* Main Loop to generate Omega (q+1)-forms *)
For[kkk=1,kkk<=n&&Length[Omega]<n-q,
  W=Map[MultiContraction[#,X,x]&,OmegaLast];
  Omegak=FormSimplify[Map[Wedge[LieDerivative1[f,#,x],DH]&,W]]; (* Omegak has \
generic u *)
  Omegak=Delete[Omegak,Position[Omegak,0]];
  (* ushort=Apply[Union,Map[Cases[Omegak,#,Infinity]&,u]]; *)
  ushort=u;
  u0=0*ushort;
  Omega00=Omegak/.Inner[Rule,ushort,u0,List];
  Omega00=Delete[Omega00,Position[Omega00,0]];
  Omega0={};
  If[Omega00==={},Omega0=Omega0,Map[If[InSpanOverReals[Omega0,Omega00[[#]],x],\

  Omega0=Omega0,Omega0=Join[Omega0,
       {Omega00[[#]]}]]&,Range[Length[Omega00]]]
       ];
  For[k=1,k<=Length[ushort],
    u0=ReplacePart[u0,1,k];
    U1=Permutations[u0];
    For[kk=1,kk<=Length[U1],
       U1kk=U1[[kk]];
       If[ushort=!={},rulek=Inner[Rule,ushort,U1kk,List],{}];
       (* Omega0=FormBasis[Omegak/.rulek,x]; *)
       If[(Omegak/.rulek)==={},Omega0=Omega0,
       Map[If[InSpanOverReals[Omega0,Omegak[[#]]/.rulek,x],Omega0=Omega0,\
Omega0=Join[Omega0,
       {Omegak[[#]]/.rulek}]]&,Range[Length[Omegak]]]
       ];
       kk++
       ];       
    k++
    ];
  Omega0=SimplifyFormBasisOverReals[Omega0,x];
  OmegaLast=Omega0;
  Map[If[RankCodistribution[Omega,x]===RankCodistribution[Join[Omega,{Omega0[[\
#]]}],x],
  Omega=Omega,Omega=Join[Omega,{Omega0[[#]]}]]&,Range[Length[Omega0]]
  ];
  kkk++
  ];
Omega
];

(*
PDESolve
*)

Clear[PDESolve]
PDESolve[RHS_List,var_List]:=Module[{n=Length[var],U,V,sol,k=1},
If[Length[RHS]<n,Print["Insufficient equations."];Return[{}]];
If[Length[RHS]>n,Print["More equations than coordinates."];Return[{}]];
U=Table[ToExpression["u"<>ToString[k]<>"["<>ToString[var[[k]]]<>"]"],{k,n}];
V=U[[1]];
While[k<=n,
  sol=DSolve[D[V,var[[k]]]==RHS[[k]],U[[k]],var[[k]]];
  If[k<n,V=(V/.sol[[1]])/.C[1]->U[[k+1]],V=(V/.sol[[1]])/.C[1]->0];
  k++
];
V=If[(Abs[V/. Inner[Rule, var, 0*var, List]] < \[Infinity]),
    Simplify[V-(V/.Inner[Rule,var,0*var,List])],Simplify[V]]
];

(*
Transform to TVLOI
*)

Clear[LinearizeToOutputInjection]
LinearizeToOutputInjection[f_?VectorQ, h_?VectorQ, x_?VectorQ, u_?VectorQ] := 
    Module[{Ind, Seq, OI, X, Y, w, W, n = Length[x], q = Length[h], dx, dh, 
        RHs, RHS, Trans},
      (* Perform observability test. *)
      {Ind, Seq} = ControlSequences[f, h, u, x];
      OI = ObservabilityIndices[f, h, x, u, Seq];
      If[Sum[OI[[i]], {i, Length[OI]}] =!= n, 
        Print["Observability indices are not well defined."]; Return[{}]];
      Y = YEqns[f, h, x, u, Seq];
      X = ConstructX[f, h, x, u, Y, OI];
      w = OmegaForms[f, h, u, x, X];
      (* Test to insure dim w is n - q *)
      (* Checks for solvability here, i.e., d[i_X(w)] = 0 *) 
      W = Map[MultiContraction[#, X, x] &, w];
      If[Length[W] =!= n - q, 
        Print[
          "dim \[CapitalOmega] = " <> ToString[Length[W]] <> ", " <> 
            ToString[n - q] <> " expected."]
        ];
      (* Print[Map[FormSimplify[d[#]] &, W]]; *)
      If[Inner[UnsameQ, Map[FormSimplify[d[#]] &, W], 
          Table[0, {i, Length[W]}], Or], 
        Print["Integrability conditions are not satisfied."]; Return[{}]
        ];
      dx = Map[d[#] &, x];
      dh = Jacob[h, x].dx;
      RHs = Join[dh, W[[Range[n - q]]]];
      RHS = Transpose[Map[Coefficient[RHs, #] &, dx]];
      Trans = Map[PDESolve[#, x] &, RHS];
      (*
        z = Map["z" <> ToString[#] &, Range[Length[x]]];
        InvTrans = InverseTransformation[x, z, Trans];
        {newf, newg} = 
          TransformSystem[f /. u -> 0, Coefficient[f, u], x, z, Trans, 
            InvTrans];
        newf + newg.u
        *)
      Trans
      ];
      
      
(*
ObservableForm
*)
Clear[ObservableForm]
ObservableForm[M_?VectorQ, W_?MatrixQ, h_?VectorQ] := 
    Module[{q = Length[h], p, STemp, S, SS, SM, T, kk}, p = Length[W];
      S = Table["S" <> ToString[i], {i, q}];
      SS = W[[Range[q]]];
      SM = M[[Range[q]]];
      If[Rank[SS] =!= q, Print["Outputs are not independent!"]; Return[{}]];
      For[k = 1, k <= q, k++, S[[k]] = {M[[k]]}];
      For[j = q + 1, j <= p, j++, STemp = Join[SS, {W[[j]]}];
        If[Rank[STemp] =!= Rank[SS], SS = STemp; kk = Mod[j, q];
          If[kk === 0, kk = q]; S[[kk]] = Join[S[[kk]], {M[[j]]}]]];
      T = {};
      Map[(T = Join[T, S[[#]]]) &, Range[q]];
      {T, Map[Length[#] &, S]}
   ];
ObservableForm[f_?VectorQ, h_?VectorQ, x_?VectorQ, u_?VectorQ, 
    Seq_List] := 
  Module[{p = Length[Seq], Seqk, k = 1, LL, M = h, W, nh = Length[h], pk},
    W = Jacob[h, x];
    While[k <= p, Seqk = Seq[[k]];
      pk = Length[Seqk];
      LL = {};
      While[Seqk =!= {}, Lkh = h;
        Map[(Lkh = LieDerivative[f /. Inner[Rule, u, #, List], Lkh, x]) &, 
          Seqk[[1]]];
        LL = Join[LL, Lkh];
        Seqk = Drop[Seqk, 1]];
      M = Join[M, LL];
      W = Join[W, Jacob[LL, x]];
      k++];
   ObservableForm[M, W, h]
];
ObservableForm[f_?VectorQ, h_?VectorQ, x_?VectorQ, u_?VectorQ] := 
Module[{Ind, Seq}, 
   {Ind, Seq} = ControlSequences[f, h, u, x];
   ObservableForm[f, h, x, u, Seq]
];
(* **************************************** *)
(*                  Utility                 *)
(* **************************************** *)

(*Right Inverse*)
RightInverse[A_?MatrixQ] := 
  Module[{m, n, test, Id, B, DD, DD1, DD2, ZeroRow, G, IndexSet, XX, row, 
      RowNo}, {m, n} = Dimensions[A];
    Id = IdentityMatrix[m];
    B = Transpose[Join[Transpose[A], Id]];
    DD = RowReduce[B];
    DD1 = DD[[Range[1, m], Range[1, n]]];
    DD2 = DD[[Range[1, m], Range[n + 1, n + m]]];
    {ZeroRow} = Table[0, {1}, {m}];
    G = Position[DD1, 1];
    IndexSet = {}; RowNo = 1;
    Do[(If[G[[j, 1]] == RowNo, IndexSet = Append[IndexSet, G[[j, 2]]];
          RowNo = RowNo + 1]), {j, Length[G]}];
    XX = {}; row = 1;
    Do[(If[Intersection[{j}, IndexSet] == {}, XX = Append[XX, ZeroRow], 
          XX = Append[XX, DD2[[row]]]; row = row + 1;]), {j, n}];
    XX]

(*Left Inverse*)
LeftInverse[A_?MatrixQ] := Module[{B, XX}, B = Transpose[A];
    XX = Transpose[RightInverse[B]]]
(* ********************************************************************** *)
(* ********************************************************************** *)

(* ********************************************************************** *)
(* ********************************************************************** *)
Protect[ObservabilityIndices,LinearizeToOutputInjection,ObservableForm]


End[]
EndPackage[ ]

(* ********************************************************************** *)
(* ********************************************************************** *)
If[!spell1, On[General::spell1]];
If[!spell, On[General::spell]];
